'use strict';

const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

const outputPath = path.join(__dirname, 'Smoke-Flows-TestCases.xlsx');

/** Mirrors tests/smoke/smoke.data.ts HOME_TILES for Flow 1 V6 export */
const HOME_TILES = [
  { name: 'All Products', assertType: 'urlIncludes', assertValue: 'select-category' },
  { name: 'Item Search', assertType: 'containsText', locatorKey: 'itemSearchHeading', assertValue: 'Product Search' },
  { name: 'Rivaah', assertType: 'visible', locatorKey: 'rivaahMenuItem', assertValue: 'Rivaah' },
  { name: 'Customer Order', assertType: 'visible', locatorKey: 'customerOrderHeading', assertValue: 'Customer Order' },
  { name: 'Best Deal', assertType: 'visible', locatorKey: 'brandInCurrentFilters', assertValue: 'BRAND' },
  { name: 'Smart Image Search', assertType: 'containsText', locatorKey: 'smartImageSearchHeading', assertValue: 'Search With Image' },
  { name: 'ECOM Stock Visibility', assertType: 'visible', locatorKey: 'itemSearchTextbox', assertValue: 'Item Search' },
  { name: 'Find Price', assertType: 'visible', locatorKey: 'lotNumberTextbox', assertValue: 'LOT Number' },
  { name: 'Estimation Slip', assertType: 'containsText', locatorKey: 'estimationSlipHeading', assertValue: 'Estimation Slip' },
  { name: 'Solitaire UIN', assertType: 'containsText', locatorKey: 'solitaireUinHeading', assertValue: 'UIN Search' },
  { name: 'Gold Coin Stock Visibility', assertType: 'visible', locatorKey: 'goldKaratageHeading', assertValue: 'Gold Karatage' },
  { name: 'Stock Visibility', assertType: 'visible', locatorKey: 'itemSearchTextbox', assertValue: 'Item Search' },
  { name: 'My Store Stock', assertType: 'visible', locatorKey: 'makeOwnCatalogueButton', assertValue: 'Make your own catalogue' },
  { name: 'Open IBT Action - Urgent', assertType: 'visible', locatorKey: 'ibtHeading', assertValue: 'Inter Boutique Transfer' },
  { name: 'Report', assertType: 'urlIncludes', assertValue: 'order-tracking' },
  { name: 'Customer Wishlist', assertType: 'visible', locatorKey: 'customerWishlistText', assertValue: 'Customer with Wishlist Items' },
  { name: 'Solitaire Products', assertType: 'visible', locatorKey: 'brandInCurrentFilters', assertValue: 'BRAND' },
  { name: 'New Collections', assertType: 'visible', locatorKey: 'makeOwnCatalogueButton', assertValue: 'Make your own catalogue' },
  { name: 'High Value Studded', assertType: 'visible', locatorKey: 'makeOwnCatalogueButton', assertValue: 'Make your own catalogue' },
  { name: 'Silver Collections', assertType: 'urlIncludes', assertValue: 'silver-collections' },
  { name: 'Size Based Search', assertType: 'visible', locatorKey: 'itemSearchTextbox', assertValue: 'Item Search' },
  { name: 'Engagement -Min 7 Day Delivery', assertType: 'visible', locatorKey: 'makeOwnCatalogueButton', assertValue: 'Make your own catalogue' },
  { name: 'National/Regional Best Seller', assertType: 'urlIncludes', assertValue: 'national-best-seller' },
  { name: 'Browse Store Stock', opensNewTab: true, assertType: 'visible', locatorKey: 'browseStoreStockPopupText', assertValue: 'Welcome to TBO.. Please Scan' },
  { name: 'KVI&FMC', assertType: 'visible', locatorKey: 'scanButton', assertValue: 'Scan' },
  { name: 'Shubh Gold Express', assertType: 'visible', locatorKey: 'shubhGoldText', assertValue: 'SHUBH GOLD EXPRESS' },
  { name: 'Home Delivery', assertType: 'visible', locatorKey: 'homeDeliveryText', assertValue: 'HomeHome Delivery Breadcrumb' },
  { name: 'Chatbot', assertType: 'visible', locatorKey: 'chatbotText', assertValue: 'GenAI Agents for APEX Inbuilt' },
];

const LOCATOR_MAP = {
  itemSearchHeading: 'css=#R23471834620407112_heading',
  rivaahMenuItem: 'role=menuitem|Rivaah',
  customerOrderHeading: 'role=heading|Customer Order Management',
  brandInCurrentFilters: 'Current filters region label "BRAND" (getByLabel Current filters → text BRAND)',
  smartImageSearchHeading: 'css=#search-with-image_heading',
  itemSearchTextbox: 'role=textbox|Item Search [ Enter 14 digit',
  lotNumberTextbox: 'role=textbox|LOT Number',
  estimationSlipHeading: 'css=#R28416661007795401_heading',
  solitaireUinHeading: 'css=#R924688565586912713_heading',
  goldKaratageHeading: 'role=heading|Gold Karatage',
  makeOwnCatalogueButton: 'role=button|Make your own catalogue',
  ibtHeading: 'role=heading|Inter Boutique Transfer',
  customerWishlistText: 'text=Customer with Wishlist Items',
  browseStoreStockPopupText: 'text=Welcome to TBO.. Please Scan',
  scanButton: 'role=button|Scan',
  shubhGoldText: 'text=SHUBH GOLD EXPRESS',
  homeDeliveryText: 'text=HomeHome Delivery Breadcrumb',
  chatbotText: 'text=GenAI Agents for APEX Inbuilt',
};

function tileAssertion(tile) {
  if (tile.assertType === 'urlIncludes') {
    return `expect(page).toHaveURL(/${tile.assertValue}/) — destination URL must contain "${tile.assertValue}"`;
  }
  if (tile.assertType === 'containsText') {
    const loc = LOCATOR_MAP[tile.locatorKey] || tile.locatorKey;
    return `expect(locator).toContainText("${tile.assertValue}") — locator: ${loc}`;
  }
  const loc = LOCATOR_MAP[tile.locatorKey] || tile.locatorKey;
  return `expect(locator).toBeVisible() — locator: ${loc}, visible text/value: "${tile.assertValue}"`;
}

function row(flow, stepId, title, steps, expected, assertion) {
  return { Flow: flow, 'Step ID': stepId, Title: title, Steps: steps, 'Expected Result': expected, 'Automation Assertion': assertion };
}

const rows = [];

// ── Flow 1 ──────────────────────────────────────────────────────────────────
const F1 = 'Flow 1 — Home Navigation Hub';
rows.push(row(F1, 'V0', 'Login to Endless Aisle',
  '1. Navigate to LOGIN_URL from .env (e.g. https://ai-test.titanrts.com/ords/r/tjdcom/ea/login?)\n2. Verify Username, Password, and LOGIN › button are visible\n3. Enter LOGIN_USER and LOGIN_PASS from .env\n4. Click LOGIN ›',
  'User lands on Home; navigation tile grid is visible.',
  'URL: expect(page).toHaveURL(/login/) on login page.\nFields: role=textbox name "Username", role=textbox name "Password", role=button name "LOGIN ›" — all toBeVisible().\nAfter click: getByLabel("Navigation", exact).getByRole("list") (nav tile list) toBeVisible() timeout 20s.'));

rows.push(row(F1, 'V1', 'Verify Home page after login',
  '1. After login, remain on Home page',
  'URL contains "home"; tile grid and user menu are visible.',
  'expect(page).toHaveURL(/home/).\nnavTileList = getByLabel("Navigation", exact).getByRole("list") → toBeVisible().\nuserMenuButton = getByRole("button", name /TEST_EA/i) → toBeVisible().'));

rows.push(row(F1, 'V2', 'Verify home tile count is 28',
  '1. Count list items under Navigation tile list',
  'Exactly 28 tiles on Home.',
  'expect(HOME_TILES.length).toBe(28).\nactualTileCount = navTileList.getByRole("listitem").count() → expect.soft(actualTileCount).toBe(28).'));

rows.push(row(F1, 'V3', 'Verify all 28 tile headings are visible',
  '1. For each expected tile name, check heading inside tile link',
  'Each of 28 tile names has a visible H3 heading.',
  'For each name in EXPECTED_TILE_NAMES: tileHeading(name) = getByRole("link", name "Card Image {name}").getByRole("heading", level 3) → expect.soft().toBeVisible().'));

rows.push(row(F1, 'V4', 'Verify all 28 tile images are visible',
  '1. For each expected tile name, check card image inside tile link',
  'Each tile shows Card Image.',
  'For each name: tileImage(name) = tile link.getByRole("img", name "Card Image") → expect.soft().toBeVisible().'));

rows.push(row(F1, 'V5', 'Verify tile order on Home',
  '1. Read H3 heading text for each listitem in order',
  'Tile order matches EXPECTED_TILE_NAMES sequence in smoke.data.ts.',
  'getTileNames() returns heading texts; expect.soft(actualTileNames).toEqual(EXPECTED_TILE_NAMES) — 28 names in defined order.'));

for (const tile of HOME_TILES) {
  const navNote = tile.opensNewTab
    ? 'Click tile → wait for popup → assert on popup → close popup (no return home via goHome).'
    : 'Click tile → assert destination → page.goto(saved homeUrl) to return Home.';
  rows.push(row(F1, 'V6', `Navigate tile: ${tile.name}`,
    `1. From Home, click link getByRole("link", name "Card Image ${tile.name}")\n2. ${navNote}`,
    `Tile "${tile.name}" opens correct destination (${tile.assertType}: ${tile.assertValue}).`,
    `Click: getByRole("link", name "Card Image ${tile.name}").\n${tileAssertion(tile)}${tile.opensNewTab ? '\nUses page.waitForEvent("popup").' : '\nThen goHome(homeUrl) — reload saved post-login URL.'}`));
}

rows.push(row(F1, 'Logout', 'Sign out',
  '1. Click user menu button (TEST_EA)\n2. Click menuitem "Sign Out"',
  'User is signed out.',
  'userMenuButton = getByRole("button", name /TEST_EA/i).click();\ngetByRole("menuitem", name "Sign Out").click().'));

// ── Flow 2 ──────────────────────────────────────────────────────────────────
const F2 = 'Flow 2 — Best Deal SKU search and detail';
rows.push(row(F2, 'V0', 'Login',
  '1. Same as Flow 1 V0 (login())',
  'Home page loads.',
  'Same as Flow 1 V0; then expect(page).toHaveURL(/home/).'));

rows.push(row(F2, 'V1', 'Open Home from menu',
  '1. Click menubar menuitem "Home"',
  'Stays on / confirms home context.',
  'getByRole("menuitem", name "Home").click();\nexpect(page).toHaveURL(/home/).'));

rows.push(row(F2, 'V2', 'Open Best Deal',
  '1. Click home tile link "Card Image Best Deal"\n2. Verify Best Deal is active in menu',
  'Best Deal listing page loads.',
  'getByRole("link", name "Card Image Best Deal").click();\ngetByRole("menuitem", name "Best Deal") → toBeVisible() timeout 20s.'));

rows.push(row(F2, 'V3', 'Search static SKU in Best Deal listing',
  '1. In sidebar searchbox "Search", enter FLOW2.staticSku (512018FASAA00)\n2. Press Enter',
  'Search Results region shows one visible product link for that SKU.',
  'getByRole("searchbox", name "Search").fill("512018FASAA00") + press Enter.\ngetByRole("region", name "Search Results").locator(\'a[href*="512018FASAA00"]\').filter(visible).first() → toBeVisible() timeout 30s.\nConfig: FLOW2.staticSku in smoke.data.ts; pattern /[0-9A-Z]{10,16}/.'));

rows.push(row(F2, 'V4a', 'Open product detail from listing',
  '1. Click visible product link in Search Results for SKU\n2. If heading "Kindly navigate to home and search again." appears → click button "OK"\n3. Fallback: page.goto(href from listing link) or Home → Best Deal → search → goto\n4. If still failing, recoverListingProductDetailViaBestDeal(sku)',
  'Product detail page loads (not product-discount error page).',
  'Click: listing link a[href*="512018FASAA00"] in Search Results.\nDismiss: getByRole("heading", /Kindly navigate to home/) + getByRole("button", "OK").\nURL: expect(page).toHaveURL(/product-detail(?!-discount)|discount-product-details(?:-all-store)?/) timeout 30s.\nURL must include SKU: toHaveURL(RegExp SKU).\nTypical href: /discount-product-details-all-store?p93_sku=512018FASAA00.'));

rows.push(row(F2, 'V4b', 'Validate SKU on product detail',
  '1. On product detail page, confirm SKU text and optional heading/label',
  'Same SKU 512018FASAA00 visible on detail; URL matches detail pattern.',
  'getByText("512018FASAA00", exact).filter(visible).first() → toBeVisible().\nIf present: getByRole("heading", name /Product Detail -/) and text "SKU" → toBeVisible().\nURL: product-detail(?!-discount) OR discount-product-details(-all-store)?; URL contains SKU.'));

// ── Flow 3 ──────────────────────────────────────────────────────────────────
const F3 = 'Flow 3 — All Products, sort, export, share';
rows.push(row(F3, 'V0', 'Login',
  '1. Same as Flow 1 V0',
  'Home loads.',
  'login() + expect(page).toHaveURL(/home/) after Flow 1 V0 assertions.'));

rows.push(row(F3, 'V1', 'Home menu',
  '1. Click menuitem "Home"',
  'On home.',
  'getByRole("menuitem", name "Home").click(); expect(page).toHaveURL(/home/).'));

rows.push(row(F3, 'V2', 'Open All Products and verify categories',
  '1. Click link "Card Image All Products"\n2. Verify category links: Earrings, Bangles, Mangalsutra, Finger Rings, Chains, Necklace, Others',
  'All 7 category links visible.',
  'getByRole("link", name "Card Image All Products").click().\nFor each category in FLOW3.categories: getByRole("link", name "{category}") → expect.soft().toBeVisible().'));

rows.push(row(F3, 'V2.1', 'Select Earrings category and filters',
  '1. Click link "Earrings" (first match)\n2. Verify side column toggle\n3. Verify Current filters shows Product = Earrings',
  'Earrings listing with filters applied.',
  'getByRole("link", name "Earrings").first().click().\ngetByRole("button", name "Expand / Collapse Side Column") → toBeVisible().\n.a-FS-currentList[aria-label="Current filters"]: label "Product" + button "Clear Product Earrings" → toBeVisible().'));

rows.push(row(F3, 'V2.2', 'Skip & Continue and brand filter',
  '1. If button "Skip & Continue" visible, click it\n2. Verify Brand and Product filters in Current filters',
  'Brand filter selected; Product still Earrings.',
  'getByRole("button", name "Skip & Continue") — click if visible.\nCurrent filters: label Brand + button matching /Clear Brand/i; label Product + button "Clear Product Earrings".'));

rows.push(row(F3, 'V3a', 'Sort Low to High — verify ascending prices',
  '1. Click button "💰 Low to High"\n2. Wait for Search Results region and at least 3 "₹ … Approx." prices\n3. Read first 3 prices',
  'First 3 listing prices are in ascending order.',
  'getByRole("button", name "💰 Low to High").click().\ngetByRole("region", name "Search Results") + text matching /₹\\s*[\\d,]+\\s*Approx\\./ — poll count >= 3.\nassertAscending: values[0] <= values[1] <= values[2].'));

rows.push(row(F3, 'V3b', 'Sort again — verify descending prices',
  '1. Click "💰 Low to High" again (toggle)\n2. Read first 3 prices',
  'First 3 prices in descending order.',
  'Same button click + waitForListingPricesStable(3).\nassertDescending: values[0] >= values[1] >= values[2].'));

rows.push(row(F3, 'V4', 'Select products for export',
  '1. Click up to 3 elements with id ending "_share" on listing\n2. Verify each SKU shows selected state',
  'At least 3 SKUs selected; first SKU in Export List.',
  'locator [id$="_share"] — click until 3 SKUs collected; id format {SKU}_share.\nexpect(locator [id="{SKU}_selected"]).toBeVisible().\ngetByRole("heading", name "Export List") → toBeVisible().\nlisting link a[href*="{firstSku}"] still visible.'));

rows.push(row(F3, 'V5', 'Open first exported SKU product detail',
  '1. Click listing product link for first selected SKU\n2. Validate detail page\n3. Browser back',
  'Product detail shows same SKU; returns to listing.',
  'listingProductLinkForSku(sku).click().\nassertProductDetailForSku (URL + getByText sku exact visible).\ngoBack().'));

rows.push(row(F3, 'V6', 'Deselect exported products',
  '1. Click each [id="{SKU}_selected"] toggle to deselect',
  'SKU no longer in selected/export state.',
  'exportSelectedButton(sku) = locator [id="{sku}_selected"] — click then expect.toBeHidden().'));

rows.push(row(F3, 'V7a', 'Share via WhatsApp',
  '1. Select 1 product for export again\n2. Click #shareBtn\n3. Click listitem "Share via WhatsApp"\n4. Fill Customer Name *, Mobile Number *, RSO Name *; Purpose dropdown FUTURE\n5. Click Send',
  'Export list still visible after send.',
  'css=#shareBtn.click(); getByRole("listitem", name "Share via WhatsApp").click().\nFields: Customer Name * = demo, Mobile = 7898778883, RSO = demo, Purpose = FUTURE (FLOW3.whatsapp).\ngetByRole("button", name "Send").click().\ngetByRole("heading", name "Export List") → toBeVisible().'));

rows.push(row(F3, 'V7b', 'Share via PDF catalogue',
  '1. Select 1 product again (basket cleared after WhatsApp)\n2. Click #shareBtn → listitem "Make your own Catalogue"\n3. If dialog "Enter Details" — fill Customer Name *, Mobile *, RSO Name * (defaults: Test Customer, 9999999999, Test RSO)\n4. Click Download; close popup if opened',
  'PDF download flow completes without blocking confirmation error.',
  'shareViaPdf: #shareBtn → "Make your own Catalogue".\nalertdialog "Confirmation" with OK — if blocks, test throws.\ndialog "Enter Details" textboxes filled → not.toBeEmpty() on all three.\ngetByRole("button", name "Download").click(); optional popup closed.'));

rows.push(row(F3, 'Logout', 'Sign out',
  '1. User menu → Sign Out',
  'Logged out.',
  'Same as Flow 1 logout.'));

// ── Flow 4 ──────────────────────────────────────────────────────────────────
const F4 = 'Flow 4 — Item Search, customer, factory booking, order details';
rows.push(row(F4, 'V0', 'Login',
  '1. login()',
  'Home.',
  'expect(page).toHaveURL(/home/).'));

rows.push(row(F4, 'V1', 'Home menu',
  '1. Click menuitem Home',
  'On home.',
  'getByRole("menuitem", name "Home").click().'));

rows.push(row(F4, 'V2a', 'Discover SKU from All Products',
  '1. Click "Card Image All Products"\n2. Click category link "Earrings"\n3. If "Skip & Continue" visible, click\n4. Click listing link "Elevate your everyday vibe"\n5. Read 14-char SKU from Product Detail region / #P5_PRODUCT',
  'Valid 14-character SKU captured (dynamic, not hardcoded).',
  'getByRole("link", name "Card Image All Products").click().\ngetByRole("link", name "Earrings").first().click().\nSkip & Continue if visible.\ngetByRole("link", name "Elevate your everyday vibe").first().click().\nexpect URL /product-detail/ timeout 30s.\ngetByRole("region", name "Product Detail") + css=#P5_PRODUCT → SKU regex /^[A-Z0-9]{14}$/.'));

rows.push(row(F4, 'V3', 'Item Search — enter discovered SKU',
  '1. Click Home menu\n2. Click "Card Image Item Search" (or goto BASE_URL product-detail-item-search)\n3. Press Escape (dismiss overlays)\n4. Fill textbox "Enter item code or scan The QR" with SKU; press Enter (twice in spec)\n5. Dismiss "Kindly provide the full Item code" alert via OK if shown',
  'Stock Availability heading visible; no Error Message region.',
  'getByRole("link", name "Card Image Item Search").\ngetByRole("textbox", name "Enter item code or scan The QR") — clear, fill, Enter.\nheading level 2 name /Stock Availability/i → toBeVisible() 30s.\nNo region "Error Message" visible.'));

rows.push(row(F4, 'V4', 'Confirm SKU on item search result',
  '1. Close lightbox if open (fancybox close)\n2. Verify Stock Availability heading still visible',
  'Item search shows stock for searched SKU.',
  'Close .fancybox-close or similar if visible.\ngetByRole("heading", /Stock Availability/i, level 2) → toBeVisible().'));

rows.push(row(F4, 'V5', 'Select customer (Without Payment)',
  '1. Click "Select Customer to Book" (reload page first if not visible after 60s)\n2. In iframe[title="Customer"]: fill "Enter Customer Mobile #" with 8754481080; Search\n3. Verify text "Balamurugan H"; click OK\n4. Wait for navigation; Stock Availability heading returns',
  'Customer selected; booking flow continues. If sold out, test fails with explicit message.',
  'getByRole("button", name "Select Customer to Book") — visible 60s or check stock text /sold out|no stock available/.\nframeLocator iframe[title="Customer"]: textbox mobile, button Search.\nframe getByText("Balamurugan H") → visible; button OK + waitForNavigation.\nStock Availability heading visible again 30s.'));

rows.push(row(F4, 'V6', 'Book factory stock (Without Payment)',
  '1. Click "Book Factory Stock"\n2. In iframe[title="Factory Request"]: verify Yes/No; select radio "No"; Reason dropdown NO_STOCK; check "I confirm and proceed forward"; Confirm',
  'Factory request submitted.',
  'getByRole("button", name "Book Factory Stock").click().\niframe[title="Factory Request"]: getByText Yes/No; radio "No"; getByLabel("Reason").selectOption("NO_STOCK"); text confirm; button "Confirm".'));

rows.push(row(F4, 'V7', 'POSS order details',
  '1. Click active POSS button: css=.btn-active[data-action*="pageId=44"]\n2. In dialog "Order Details", read iframe content\n3. Verify discovered SKU and customer name; Close dialog',
  'Order details show correct SKU and Balamurugan H.',
  'css=.btn-active[data-action*="pageId=44"].click().\ngetByRole("dialog", name "Order Details") → toBeVisible().\ndialog.frameLocator("iframe"): getByText(sku, exact) + getByText("Balamurugan H", exact) → visible.\ngetByRole("button", name "Close") on dialog.'));

// Build workbook
const headers = ['Flow', 'Step ID', 'Title', 'Steps', 'Expected Result', 'Automation Assertion'];
const dataRows = rows.map((r) => [
  r.Flow,
  r['Step ID'],
  r.Title,
  r.Steps,
  r['Expected Result'],
  r['Automation Assertion'],
]);

const infoRows = [
  ['Endless Aisle — Smoke Flows Test Cases (Automation Mapped)'],
  ['Source: tests/smoke/smoke.spec.ts, smoke.page.ts, smoke.data.ts, smoke.locators.ts'],
  ['Generated:', new Date().toISOString().slice(0, 10)],
  [],
  ['Environment'],
  ['BASE_URL', 'https://ai-test.titanrts.com/ords/r/tjdcom/ea/ (from .env)'],
  ['LOGIN_URL', 'from .env LOGIN_URL'],
  ['Credentials', 'LOGIN_USER / LOGIN_PASS from .env (e.g. test_ea)'],
  [],
  ['Flow 2 test data', 'FLOW2.staticSku = 512018FASAA00'],
  ['Flow 3 test data', 'Category Earrings; WhatsApp: demo / 7898778883 / demo / FUTURE'],
  ['Flow 4 test data', 'Listing link "Elevate your everyday vibe"; Mobile 8754481080; Customer Balamurugan H; Factory reason NO_STOCK'],
  [],
  ['Note', 'Flow 1 V6 has one row per home tile (28 tiles). Flow 4 SKU is discovered at runtime in V2.'],
];

const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(infoRows), 'Read Me');
const mainSheet = XLSX.utils.aoa_to_sheet([headers, ...dataRows]);
mainSheet['!cols'] = [
  { wch: 42 },
  { wch: 10 },
  { wch: 38 },
  { wch: 55 },
  { wch: 32 },
  { wch: 60 },
];
XLSX.utils.book_append_sheet(wb, mainSheet, 'Smoke Test Steps');

XLSX.writeFile(wb, outputPath);
console.log(`Wrote ${outputPath} (${rows.length} test steps)`);

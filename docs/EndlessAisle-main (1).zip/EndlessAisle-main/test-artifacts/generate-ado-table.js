const fs = require('fs');
const path = require('path');

const data = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'ProductCatalogue-master-suite.json'), 'utf8')
);

const rows = [
  '| ID | Work Item Type | Title | Test Step | Step Action | Step Expected | Area Path | Assigned To | State |',
];

for (const tc of data.test_cases) {
  const shortId = tc.id.replace('ProductCatalogue-', 'PC-');
  const headerTitle = `${shortId} — ${tc.title} [ProductCatalogue / ${tc.priority} / ${tc.suite_category}-${tc.suite_tier}]`;
  rows.push(`| | Test Case | ${headerTitle} | | | | | | Design |`);
  for (const step of tc.steps) {
    const action = step.description.replace(/\|/g, '/');
    const expected = step.expected.replace(/\|/g, '/');
    rows.push(`| | | | ${step.seq} | ${action} | ${expected} | | | |`);
  }
}

fs.writeFileSync(path.join(__dirname, 'ProductCatalogue-ADO-import-table.md'), rows.join('\n'));
console.log(`Generated ${rows.length - 1} table rows`);

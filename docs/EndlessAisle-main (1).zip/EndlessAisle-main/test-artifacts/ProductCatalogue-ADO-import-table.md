| ID | Work Item Type | Title | Test Step | Step Action | Step Expected | Area Path | Assigned To | State |
| | Test Case | PC-MS-001 — Complete browse journey — login, Earrings category, search, sort, open product detail [ProductCatalogue / P1 / Functional-End-to-End (E2E)] | | | | | | Design |
| | | | 1 | Navigate to login page at https://ai-test.titanrts.com/ords/r/tjdcom/ea/login? | Login page loads; Username and Password fields visible | | | |
| | | | 2 | Enter "test_ea" in the Username field | Username field accepts value | | | |
| | | | 3 | Enter "T@nishq-123" in the Password field | Password field accepts value (masked) | | | |
| | | | 4 | Click the "LOGIN ›" button | User is authenticated; post-login home/dashboard visible with "Card Image All Products" link | | | |
| | | | 5 | Click the "Card Image All Products" link | Select Category page loads | | | |
| | | | 6 | Click the "Earrings" category link | Earrings product listing page loads with search box and filter panels | | | |
| | | | 7 | Click the "Enter keyword or scan" search field then click the "Search" button without entering text | Product grid refreshes or remains visible; no blocking error | | | |
| | | | 8 | Click the "💰 Low to High" sort button | Products reorder by ascending price or sort indicator updates | | | |
| | | | 9 | Click a product tile in the Earrings grid to open product detail | Product detail page loads; URL contains "product-detail" | | | |
| | | | 10 | Verify product detail page displays product information | Product detail content visible; page URL matches pattern .../product-detail?p5_query_id=... | | | |
| | Test Case | PC-MS-002 — Browse Earrings category after login and verify listing page elements [ProductCatalogue / P1 / Functional-Happy Path] | | | | | | Design |
| | | | 1 | Log in with username "test_ea" and password "T@nishq-123" | Login succeeds; home page visible | | | |
| | | | 2 | Navigate to All Products via "Card Image All Products" link | Select Category page displayed | | | |
| | | | 3 | Click the "Earrings" category link | Earrings listing page opens | | | |
| | | | 4 | Verify search field "Enter keyword or scan" is visible | Search textbox visible and enabled | | | |
| | | | 5 | Verify product grid displays at least one product tile | One or more product tiles visible in grid | | | |
| | Test Case | PC-MS-003 — Login rejected with valid username and invalid password [ProductCatalogue / P1 / Functional-Negative] | | | | | | Design |
| | | | 1 | Navigate to login page | Login form displayed | | | |
| | | | 2 | Enter "test_ea" in the Username field | Username accepted | | | |
| | | | 3 | Enter "WrongPass!99" in the Password field | Password accepted in field | | | |
| | | | 4 | Click the "LOGIN ›" button | Login fails; user remains on login page; [Verify exact error message in system] | | | |
| | Test Case | PC-MS-004 — Login blocked when Username and Password are both empty [ProductCatalogue / P2 / Functional-Negative] | | | | | | Design |
| | | | 1 | Navigate to login page | Login form displayed with empty Username and Password fields | | | |
| | | | 2 | Click the "LOGIN ›" button without entering credentials | Login not completed; user remains on login page; [Verify exact error message in system] | | | |
| | Test Case | PC-MS-005 — Empty keyword search on Earrings listing executes without error [ProductCatalogue / P2 / UI-Field Validation] | | | | | | Design |
| | | | 1 | Open Earrings category listing page | Earrings listing page loaded | | | |
| | | | 2 | Click the "Enter keyword or scan" field leaving it empty | Search field focused; no validation error on focus | | | |
| | | | 3 | Click the "Search" button | Search executes; product grid remains visible; no blocking error dialog | | | |
| | Test Case | PC-MS-006 — Toggle price sort using "💰 Low to High" control twice [ProductCatalogue / P2 / UI-UI Modes] | | | | | | Design |
| | | | 1 | Open Earrings product listing page | Product grid visible with sort controls | | | |
| | | | 2 | Click the "💰 Low to High" sort button | Products reorder ascending by price or sort state indicator updates | | | |
| | | | 3 | Click the "💰 Low to High" sort button a second time | Sort toggles (e.g. to High to Low) or remains stable without UI error | | | |
| | | | 4 | Verify product grid still displays results after sort toggles | At least one product tile visible; no error banner | | | |
| | Test Case | PC-MS-007 — Expand and collapse all filter accordion sections on Earrings listing [ProductCatalogue / P2 / UI-Grid / Table] | | | | | | Design |
| | | | 1 | Open Earrings product listing page | Filter panel visible with accordion headings | | | |
| | | | 2 | Click each filter heading (Brand, Available at Factory, Price, Weight Band, Jewellery Type, Product, Gender, Collection, Metal Color, Type, Community, Trousseau, Gold Karatage, Occasion, Diamond Clarity, Pendant Height, Pendant Width, Size) once to expand | Each section expands or toggles without error; filter controls become visible | | | |
| | | | 3 | Click the "Earring WidthClear" control twice | Earring Width filter clears or toggles; grid updates or remains stable | | | |
| | | | 4 | Verify product grid remains visible after filter interactions | Product grid visible; no application error | | | |
| | Test Case | PC-MS-008 — Search Earrings by valid keyword and verify matching results [ProductCatalogue / P2 / Functional-Happy Path] | | | | | | Design |
| | | | 1 | Open Earrings product listing page | Listing page loaded | | | |
| | | | 2 | Enter "[VALID_EARRING_KEYWORD]" in the "Enter keyword or scan" field | Keyword accepted in search field | | | |
| | | | 3 | Click the "Search" button | Product grid refreshes with results matching keyword | | | |
| | | | 4 | Verify at least one result tile relates to the search keyword | One or more product tiles visible containing or matching "[VALID_EARRING_KEYWORD]" | | | |
| | Test Case | PC-MS-009 — Search with non-existent keyword returns no matching products [ProductCatalogue / P2 / Functional-Negative] | | | | | | Design |
| | | | 1 | Open Earrings product listing page | Listing page loaded | | | |
| | | | 2 | Enter "ZZZ-NO-MATCH-99999" in the "Enter keyword or scan" field | Keyword accepted | | | |
| | | | 3 | Click the "Search" button | No matching products shown or empty-state message displayed; [Verify exact error message in system] | | | |
| | Test Case | PC-MS-010 — Search with special characters does not break listing page [ProductCatalogue / P3 / Functional-Edge] | | | | | | Design |
| | | | 1 | Enter "%&*<>" in the "Enter keyword or scan" field | Field accepts input or sanitizes safely | | | |
| | | | 2 | Click the "Search" button | Page remains functional; no server error; [Verify exact error message in system] if validation applies | | | |
| | Test Case | PC-MS-011 — Open product detail from Earrings grid and verify detail page loads [ProductCatalogue / P1 / UI-Grid / Table] | | | | | | Design |
| | | | 1 | Open Earrings product listing page | Product grid visible | | | |
| | | | 2 | Click a product tile in the grid | Navigation to product detail initiated | | | |
| | | | 3 | Verify URL contains "product-detail" and "p5_query_id" parameter | URL matches pattern .../product-detail?p5_query_id=... (e.g. IBTQRYTBO011333344 from recording) | | | |
| | | | 4 | Verify product detail content area is visible and not empty | Product detail panel visible with product attributes | | | |
| | Test Case | PC-MS-012 — Product detail query ID persists after page reload [ProductCatalogue / P2 / Advanced-Data Integrity] | | | | | | Design |
| | | | 1 | Open a product detail page and note the p5_query_id from the URL | p5_query_id captured (e.g. IBTQRYTBO011333344) | | | |
| | | | 2 | Reload the product detail page | Same product detail reloads | | | |
| | | | 3 | Verify p5_query_id in URL matches the value noted before reload | p5_query_id unchanged after reload; product detail content still visible | | | |
| | Test Case | PC-MS-013 — End-to-end navigation path from home card through category to product detail [ProductCatalogue / P2 / System-Integration (UI-level)] | | | | | | Design |
| | | | 1 | Log in and land on post-login home | Home page with "Card Image All Products" visible | | | |
| | | | 2 | Click "Card Image All Products" then "Earrings" | Earrings listing URL loaded; category context correct | | | |
| | | | 3 | Open any product from the grid | Product detail page opens with unique p5_query_id | | | |
| | | | 4 | Verify browser back navigation returns to Earrings listing | Earrings listing page restored with grid visible | | | |
| | Test Case | PC-MS-014 — Apply Brand filter on Earrings listing and verify grid updates [ProductCatalogue / P2 / Functional-Happy Path] | | | | | | Design |
| | | | 1 | Click the "Brand" filter heading to expand the section | Brand filter options visible | | | |
| | | | 2 | Select "[VALID_BRAND_NAME]" from Brand filter options | Brand filter applied | | | |
| | | | 3 | Verify product grid refreshes showing only matching brand products | Grid shows products for "[VALID_BRAND_NAME]" or empty-state if none | | | |
| | Test Case | PC-MS-015 — Price filter range validation on Earrings listing [ProductCatalogue / P2 / UI-Field Validation] | | | | | | Design |
| | | | 1 | Click the "Price" filter heading to expand | Price range inputs visible | | | |
| | | | 2 | Enter "-1" in minimum price and "abc" in maximum price fields then apply filter | Invalid price inputs rejected; [Verify exact error message in system] | | | |
| | | | 3 | Enter "[MIN_PRICE_GBP]" and "[MAX_PRICE_GBP]" as valid range and apply | Grid updates to products within price range | | | |
| | Test Case | PC-MS-016 — Unauthenticated direct access to product-detail URL redirects to login [ProductCatalogue / P1 / Functional-Negative] | | | | | | Design |
| | | | 1 | Open a new browser session without logging in | No active session | | | |
| | | | 2 | Navigate directly to product detail URL with p5_query_id=IBTQRYTBO011333344 | User redirected to login page or prompted to authenticate | | | |
| | Test Case | PC-MS-017 — Invalid p5_query_id on product detail shows controlled error [ProductCatalogue / P3 / Advanced-Error Handling] | | | | | | Design |
| | | | 1 | Navigate to product-detail URL with invalid p5_query_id=INVALID-QUERY-000 | Controlled error or not-found message shown; [Verify exact error message in system] | | | |
| | Test Case | PC-MS-018 — Rapid repeated clicks on filter headings do not freeze UI [ProductCatalogue / P3 / Functional-Edge] | | | | | | Design |
| | | | 1 | Rapidly double-click the "Brand" and "Price" filter headings multiple times | UI remains responsive; accordions toggle without script error | | | |
| | | | 2 | Verify product grid and Search control remain usable | Search field enabled; grid visible | | | |
| | Test Case | PC-MS-019 — Regression smoke — login, Earrings browse, open product detail [ProductCatalogue / P1 / System-Regression] | | | | | | Design |
| | | | 1 | Log in with "test_ea" / "T@nishq-123" (see ProductCatalogue-MS-001 steps 1–4) | Authenticated home visible | | | |
| | | | 2 | Navigate to Earrings via All Products card (see ProductCatalogue-MS-002) | Earrings grid visible | | | |
| | | | 3 | Click Search with empty keyword (see ProductCatalogue-MS-005) | Grid remains visible | | | |
| | | | 4 | Click "💰 Low to High" sort once | Sort applies without error | | | |
| | | | 5 | Open first available product tile (see ProductCatalogue-MS-011) | Product detail page loads | | | |
| | | | 6 | Verify product detail URL contains "product-detail" | Detail page confirmed; core browse path intact | | | |
| | Test Case | PC-MS-020 — Select Gold Karatage filter section and verify filter panel behaviour [ProductCatalogue / P2 / Functional-Happy Path] | | | | | | Design |
| | | | 1 | Click the "Gold Karatage" filter heading | Gold Karatage options expand | | | |
| | | | 2 | Select "[VALID_GOLD_KARATAGE]" from Gold Karatage options | Filter applied; grid refreshes | | | |
| | | | 3 | Verify product grid reflects Gold Karatage selection | Products match selected karatage or appropriate empty state shown | | | |
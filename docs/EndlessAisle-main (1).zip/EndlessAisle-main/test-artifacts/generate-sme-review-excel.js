const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

const inputPath = path.join(__dirname, 'ProductCatalogue-master-suite.json');
const outputPath = path.join(__dirname, 'ProductCatalogue-TestCases-SME-Review.xlsx');

const data = JSON.parse(fs.readFileSync(inputPath, 'utf8'));

function formatTestData(testData) {
  if (!testData || Object.keys(testData).length === 0) return '';
  return Object.entries(testData)
    .map(([key, value]) => `${key}: ${value}`)
    .join('\n');
}

function shortId(id) {
  return id.replace('ProductCatalogue-', 'PC-');
}

// Sheet 1: Document info
const infoRows = [
  ['Endless Aisle — Product Catalogue Master Test Suite'],
  ['Document for SME Review'],
  [],
  ['Module / Feature', data.meta.form_id],
  ['Environment', 'https://ai-test.titanrts.com/ords/r/tjdcom/ea/'],
  ['Total Test Cases', data.master_suite_summary.total_test_cases],
  ['Generated From', 'Playwright Codegen Analysis'],
  ['Generated Date', new Date().toISOString().slice(0, 10)],
  [],
  ['Instructions for Reviewer'],
  ['1. Review each test case in the "Test Case Summary" sheet.'],
  ['2. Validate steps and expected results in the "Test Steps Detail" sheet.'],
  ['3. Fill Review Status, SME Comments, Actual Result, and Pass/Fail columns.'],
  ['4. Use placeholders marked with [BRACKETS] — replace with valid business data where needed.'],
  [],
  ['Coverage Notes', data.coverage_notes],
  ['Dedupe Notes', data.master_suite_summary.dedupe_notes],
];

// Sheet 2: Test Case Summary (standard overview)
const summaryHeaders = [
  'Test Case ID',
  'Test Case Title',
  'Module',
  'Suite Category',
  'Suite Tier',
  'Priority',
  'Smoke Test (Y/N)',
  'Test Type',
  'Preconditions',
  'Test Data',
  'Tags',
  'Total Steps',
  'Review Status',
  'SME Comments',
  'Approved (Y/N)',
];

const summaryRows = [summaryHeaders];

for (const tc of data.test_cases) {
  summaryRows.push([
    shortId(tc.id),
    tc.title,
    data.meta.form_id,
    tc.suite_category,
    tc.suite_tier,
    tc.priority,
    tc.smoke ? 'Y' : 'N',
    tc.suite_type,
    tc.preconditions,
    formatTestData(tc.test_data),
    (tc.tags || []).join(', '),
    tc.steps.length,
    '',
    '',
    '',
  ]);
}

// Sheet 3: Test Steps Detail (standard step-by-step format)
const detailHeaders = [
  'Test Case ID',
  'Test Case Title',
  'Priority',
  'Suite Category',
  'Suite Tier',
  'Step #',
  'Test Step (Action)',
  'Expected Result',
  'Test Data / Input Value',
  'Action Type',
  'UI Label',
  'Block / Section',
  'Actual Result',
  'Pass / Fail',
  'Defect ID',
  'Tester Comments',
];

const detailRows = [detailHeaders];

for (const tc of data.test_cases) {
  for (const step of tc.steps) {
    detailRows.push([
      shortId(tc.id),
      tc.title,
      tc.priority,
      tc.suite_category,
      tc.suite_tier,
      step.seq,
      step.description,
      step.expected,
      step.test_value ?? '',
      step.action_type,
      step.ui_label ?? '',
      step.block_hint ?? '',
      '',
      '',
      '',
      '',
    ]);
  }
}

const workbook = XLSX.utils.book_new();

const infoSheet = XLSX.utils.aoa_to_sheet(infoRows);
const summarySheet = XLSX.utils.aoa_to_sheet(summaryRows);
const detailSheet = XLSX.utils.aoa_to_sheet(detailRows);

infoSheet['!cols'] = [{ wch: 28 }, { wch: 100 }];
summarySheet['!cols'] = [
  { wch: 14 },
  { wch: 55 },
  { wch: 18 },
  { wch: 14 },
  { wch: 22 },
  { wch: 10 },
  { wch: 14 },
  { wch: 10 },
  { wch: 45 },
  { wch: 40 },
  { wch: 30 },
  { wch: 12 },
  { wch: 14 },
  { wch: 30 },
  { wch: 14 },
];
detailSheet['!cols'] = [
  { wch: 14 },
  { wch: 45 },
  { wch: 10 },
  { wch: 14 },
  { wch: 22 },
  { wch: 8 },
  { wch: 55 },
  { wch: 45 },
  { wch: 35 },
  { wch: 14 },
  { wch: 22 },
  { wch: 18 },
  { wch: 25 },
  { wch: 12 },
  { wch: 12 },
  { wch: 30 },
];

XLSX.utils.book_append_sheet(workbook, infoSheet, 'Document Info');
XLSX.utils.book_append_sheet(workbook, summarySheet, 'Test Case Summary');
XLSX.utils.book_append_sheet(workbook, detailSheet, 'Test Steps Detail');

XLSX.writeFile(workbook, outputPath);

// Also export CSV versions for easy sharing
const summaryCsvPath = path.join(__dirname, 'ProductCatalogue-TestCases-Summary.csv');
const detailCsvPath = path.join(__dirname, 'ProductCatalogue-TestSteps-Detail.csv');

XLSX.writeFile(
  { SheetNames: ['Summary'], Sheets: { Summary: summarySheet } },
  summaryCsvPath,
  { bookType: 'csv' }
);
XLSX.writeFile(
  { SheetNames: ['Detail'], Sheets: { Detail: detailSheet } },
  detailCsvPath,
  { bookType: 'csv' }
);

console.log('Created:', outputPath);
console.log('Created:', summaryCsvPath);
console.log('Created:', detailCsvPath);
console.log('Test cases:', data.test_cases.length);
console.log('Total steps:', detailRows.length - 1);

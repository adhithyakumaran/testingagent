import { defineConfig } from '@playwright/test';
import 'dotenv/config';

export default defineConfig({
  testDir: './tests',
  outputDir: 'reports/test-results',

  fullyParallel: false,
  workers: 1,
  timeout: 90000,
  retries: 0,

  reporter: [
    ['list'],
    ['html', { open: 'never', outputFolder: 'reports/html-report' }],
    ['./reporters/history-reporter.ts'],
  ],

  use: {
    headless: false,
    // null viewport + --start-maximized = actual OS window size.
    viewport: null,
    launchOptions: {
      args: ['--start-maximized'],
    },
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
  },

  projects: [
    {
      name: 'chromium',
      use: {
        // Use the real installed Chrome instead of Playwright's bundled Chromium.
        // Smoke tests use tests/smoke/incognito.fixture.ts for a visible
        // incognito Chrome window.
        channel: 'chrome',
        // devices['Desktop Chrome'] sets viewport + deviceScaleFactor which
        // conflict with viewport: null — skip the spread entirely.
        viewport: null,
        deviceScaleFactor: undefined,
        contextOptions: { storageState: undefined },
      },
    },
  ],
});

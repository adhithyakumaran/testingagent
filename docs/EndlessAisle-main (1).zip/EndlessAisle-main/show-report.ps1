$nodeDir = Join-Path $env:LOCALAPPDATA 'Programs\nodejs'
$nodeExe = Join-Path $nodeDir 'node.exe'
if (-not (Test-Path $nodeExe)) {
  Write-Error "Node.js not found at $nodeDir. Install from https://nodejs.org/ or fix PATH."
  exit 1
}
$env:Path = "$nodeDir;$env:Path"
Set-Location $PSScriptRoot
& $nodeExe .\node_modules\playwright\cli.js show-report reports\html-report --port 9400

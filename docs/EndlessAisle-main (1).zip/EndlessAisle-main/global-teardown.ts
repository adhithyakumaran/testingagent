async function globalTeardown(): Promise<void> {
  console.log('\n--- Test run finished ---');
  console.log('Latest Playwright report:  npm run test:report     → http://localhost:9400');
  console.log('QA intelligence dashboard: npm run dashboard      → http://localhost:9401/dashboard/');
  console.log('All runs archived under:   reports/history/ (never deleted)\n');
}

export default globalTeardown;

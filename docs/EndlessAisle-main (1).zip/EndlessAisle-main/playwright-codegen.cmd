@echo off
cd /d "%~dp0"
node "%~dp0node_modules\playwright\cli.js" codegen %*

# EndlessAisle

## Node.js and Playwright

Node.js (with `npm` / `npx`) should be on your PATH. If this repo was set up for you, it may live at `%LOCALAPPDATA%\Programs\nodejs`.

**If `npx` is still not found in an existing terminal:** close that terminal tab and open a new one, or run:

```powershell
$env:Path = "$env:LOCALAPPDATA\Programs\nodejs;$env:Path"
```

From the project folder:

```powershell
npm install
npx playwright install
npx playwright codegen
```

You can also use `npm run codegen` (see `package.json`).

## View last test report

If `node` / `npx` is not recognized in a terminal (PATH issue), use either:

```powershell
# One-time fix for the current terminal session
$env:Path = "$env:LOCALAPPDATA\Programs\nodejs;$env:Path"
npm run test:report
```

Or run the project helpers (they use the full path to Node):

```cmd
show-report.cmd
```

```powershell
.\show-report.ps1
```

Equivalent when Node is on PATH: `npm run test:report` (opens **http://localhost:9400** — port 9400 avoids clashes with Playwright’s default 9323).

Override port: `node ./node_modules/playwright/cli.js show-report reports/html-report --port 9500`

## Run by tag (isolated tests)

Each test gets its **own browser context**: Chrome opens → login → Earrings → test steps → context closes. POM helpers and `expect.soft()` collect failures without stopping mid-test; the test still fails at the end if any soft assert failed.

| Command | What runs |
|---------|-----------|
| `npm run test:smoke` | `@smoke` only (MS-001, MS-019), in order |
| `npm run test:positive` | `@positive` happy-path tests, in order |
| `npm run test:negative` | `@negative` tests, in order |

Append `:report` to open the HTML report when finished, e.g. `npm run test:smoke:report`.

CLI equivalent: `node ./node_modules/playwright/cli.js test tests/ProductCatalogue --grep @smoke`

## QA intelligence dashboard (historical reports)

Every test run is **archived forever** under `reports/history/<run-id>/` (HTML report, videos, screenshots, metadata). Nothing is auto-deleted.

| Command | Purpose |
|---------|---------|
| `npm run test:smoke` | Run tests + archive + refresh dashboard |
| `npm run dashboard` | Serve dashboard at **http://localhost:9401/dashboard/** |
| `npm run test:report` | Open **latest** Playwright report only (port 9400) |
| `npm run dashboard:build` | Rebuild dashboard from existing `reports/history/` |

Dashboard includes:

- Executive KPIs (total runs, pass rate, failure hotspots, flaky candidates)
- Pass-rate trend (last 30 runs)
- Suite health (smoke / positive / negative)
- Click-through to **archived** Playwright HTML reports
- Filterable run history table

Install deps after pull: `npm install`

import { expect, type Locator, type Page } from '@playwright/test';
import type { TileData } from './smoke.data';
import { HOME_LOCATORS, LOCATORS, type LocatorKey } from './smoke.locators';

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing env var: ${name} — set it in .env`);
  }
  return value;
}

const LOGIN_URL = requireEnv('LOGIN_URL');
const LOGIN_USER = requireEnv('LOGIN_USER');
const LOGIN_PASS = requireEnv('LOGIN_PASS');
const BASE_URL = requireEnv('BASE_URL');

export class SmokePage {
  constructor(readonly page: Page) {}

  private locatorFromToken(token: string, targetPage: Page = this.page): Locator {
    if (token.startsWith('css=')) return targetPage.locator(token.slice(4));
    if (token.startsWith('text=')) return targetPage.getByText(token.slice(5));
    if (token.startsWith('role=')) {
      const raw = token.slice(5);
      const [role, ...nameParts] = raw.split('|');
      const name = nameParts.join('|');
      return targetPage.getByRole(role as any, { name });
    }
    throw new Error(`Invalid locator token: ${token}`);
  }

  private byKey(locatorKey: LocatorKey, targetPage: Page = this.page): Locator {
    return this.locatorForKey(locatorKey, targetPage);
  }

  private locatorForKey(locatorKey: LocatorKey, targetPage: Page): Locator {
    // Scoped locator to avoid strict-mode collisions for repeated "BRAND" text.
    if (locatorKey === 'brandInCurrentFilters') {
      return targetPage.getByLabel('Current filters').getByText('BRAND').first();
    }
    if (locatorKey === 'silverCollectionsFormItem') {
      return targetPage.locator('.t-Form-itemWrapper').first();
    }
    return this.locatorFromToken(LOCATORS[locatorKey], targetPage);
  }

  get navTileList(): Locator {
    return this.page.getByLabel(HOME_LOCATORS.navigationLabel, { exact: true }).getByRole('list');
  }

  get allTileItems(): Locator {
    return this.navTileList.getByRole('listitem');
  }

  get userMenuButton(): Locator {
    return this.page.getByRole('button', { name: HOME_LOCATORS.userButtonRegex });
  }

  tileLink(name: string): Locator {
    return this.page.getByRole('link', { name: `${HOME_LOCATORS.tileLinkPrefix}${name}` });
  }

  tileHeading(name: string): Locator {
    return this.tileLink(name).getByRole('heading', { level: 3 });
  }

  tileImage(name: string): Locator {
    return this.tileLink(name).getByRole('img', { name: HOME_LOCATORS.tileImageName });
  }

  async login(): Promise<void> {
    await this.page.goto(LOGIN_URL);

    await expect(this.page, 'V0: Login page URL should contain "login"').toHaveURL(/login/);
    await expect(this.locatorFromToken(LOCATORS.loginUsername), 'V0: Username field should be visible').toBeVisible();
    await expect(this.locatorFromToken(LOCATORS.loginPassword), 'V0: Password field should be visible').toBeVisible();
    await expect(this.locatorFromToken(LOCATORS.loginButton), 'V0: LOGIN button should be visible').toBeVisible();

    await this.locatorFromToken(LOCATORS.loginUsername).fill(LOGIN_USER);
    await this.locatorFromToken(LOCATORS.loginPassword).fill(LOGIN_PASS);
    await this.locatorFromToken(LOCATORS.loginButton).click();

    await expect(this.navTileList, 'V0: Home navigation tile list should be visible after login').toBeVisible({
      timeout: 20_000,
    });
  }

  async logout(): Promise<void> {
    await this.userMenuButton.click();
    await this.page.getByRole('menuitem', { name: HOME_LOCATORS.signOutName }).click();
  }

  async getTileCount(): Promise<number> {
    return this.allTileItems.count();
  }

  async getTileNames(): Promise<string[]> {
    const count = await this.allTileItems.count();
    const names: string[] = [];
    for (let i = 0; i < count; i++) {
      const text = await this.allTileItems.nth(i).getByRole('heading', { level: 3 }).textContent();
      names.push((text ?? '').trim());
    }
    return names;
  }

  async clickTile(name: string): Promise<void> {
    const link = this.tileLink(name);
    await link.waitFor({ state: 'visible', timeout: 15_000 });
    await link.click();
  }

  async goHome(homeUrl: string): Promise<void> {
    await this.page.goto(homeUrl);
    await this.page.waitForLoadState('domcontentloaded');
  }

  async assertTileDestination(tile: TileData, destinationPage: Page): Promise<void> {
    if (tile.assertType === 'urlIncludes') {
      await expect(
        destinationPage,
        `V6: "${tile.name}" should navigate to URL containing "${tile.assertValue}"`
      ).toHaveURL(new RegExp(tile.assertValue), { timeout: 20_000 });
      return;
    }

    if (!tile.locatorKey) {
      throw new Error(`Missing locatorKey for tile: ${tile.name}`);
    }
    const locator = this.locatorForKey(tile.locatorKey, destinationPage);

    if (tile.assertType === 'containsText') {
      await expect(
        locator,
        `V6: "${tile.name}" page should contain text "${tile.assertValue}"`
      ).toContainText(tile.assertValue, { timeout: 20_000 });
      return;
    }

    await expect(
      locator,
      `V6: "${tile.name}" destination locator "${tile.locatorKey}" should be visible`
    ).toBeVisible({ timeout: 20_000 });
  }

  async verifyTileNavigation(tile: TileData, homeUrl: string): Promise<void> {
    if (tile.opensNewTab) {
      const popupPromise = this.page.waitForEvent('popup');
      await this.clickTile(tile.name);
      const popup = await popupPromise;
      await popup.waitForLoadState('domcontentloaded').catch(() => {});
      await this.assertTileDestination(tile, popup);
      await popup.close();
      return;
    }

    await this.clickTile(tile.name);
    await this.page.waitForLoadState('domcontentloaded').catch(() => {});
    await this.assertTileDestination(tile, this.page);
    await this.goHome(homeUrl);
  }

  async clickHomeMenu(): Promise<void> {
    await this.byKey('homeMenuItem').click();
  }

  async openBestDealFromHome(): Promise<void> {
    await this.tileLink('Best Deal').click();
  }

  async assertBestDealPage(): Promise<void> {
    await expect(this.byKey('bestDealMenuItem'), 'V2: Best Deal tab/menu should be visible').toBeVisible({
      timeout: 20_000,
    });
  }

  /** Best Deal / catalogue grids render many hidden SKU nodes off-screen; scope to results. */
  get listingResultsRegion(): Locator {
    return this.page.getByRole('region', { name: 'Search Results' });
  }

  private listingProductLinkForSku(sku: string): Locator {
    return this.listingResultsRegion
      .locator(`a[href*="${sku}"]`)
      .filter({ visible: true })
      .first();
  }

  private approxPriceLocator(): Locator {
    return this.listingResultsRegion.locator('text=/₹\\s*[\\d,]+\\s*Approx\\./');
  }

  /** APEX reloads the grid after sort; wait before reading prices. */
  /** SKUs may start with a digit — use [id="..."] instead of #id CSS. */
  private exportSelectedButton(sku: string): Locator {
    return this.page.locator(`[id="${sku}_selected"]`);
  }

  private async waitForListingPricesStable(minCount = 3): Promise<void> {
    await expect(this.listingResultsRegion, 'V3: Search results should be visible').toBeVisible({
      timeout: 30_000,
    });
    const prices = this.approxPriceLocator();
    await expect(prices.first(), 'V3: Listing prices should be visible').toBeVisible({ timeout: 30_000 });
    await this.page.waitForLoadState('domcontentloaded').catch(() => {});
    await expect
      .poll(async () => prices.count(), {
        timeout: 30_000,
        message: `V3: Expected at least ${minCount} listing prices after grid refresh`,
      })
      .toBeGreaterThanOrEqual(minCount);
  }

  private parseSkuCandidates(text: string): string[] {
    const matches = text.match(/\b[A-Z0-9]{10,16}\b/g) || [];
    const filtered = matches.filter((sku) => /[A-Z]/.test(sku) && /\d/.test(sku));
    return [...new Set(filtered)];
  }

  async getRandomSkuFromListing(): Promise<string> {
    const bodyText = await this.page.locator('body').innerText();
    const skus = this.parseSkuCandidates(bodyText);
    if (!skus.length) {
      throw new Error('V3: No SKU values found on listing page to choose from.');
    }
    const idx = Math.floor(Math.random() * skus.length);
    return skus[idx];
  }

  async searchSkuInListing(sku: string): Promise<void> {
    const search = this.byKey('listingSearch');
    await expect(search, `V3: Listing search should be visible before searching SKU ${sku}`).toBeVisible();
    await search.fill(sku);
    await search.press('Enter');
    await expect(
      this.listingProductLinkForSku(sku),
      `V3: Search results should list a visible product for SKU ${sku}`
    ).toBeVisible({ timeout: 30_000 });
  }

  async openSkuFromListing(sku: string): Promise<void> {
    await this.listingProductLinkForSku(sku).click();
  }

  /** Avoid matching APEX error route `product-discount` (substring of `product-detail`). */
  private readonly productDetailUrlPattern =
    /product-detail(?!-discount)|discount-product-details(?:-all-store)?/;

  private skuInUrlPattern(sku: string): RegExp {
    return new RegExp(sku.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  }

  private async isOnProductDetailForSku(sku: string): Promise<boolean> {
    if (!this.productDetailUrlPattern.test(this.page.url())) return false;
    if (!this.skuInUrlPattern(sku).test(this.page.url())) return false;
    return this.page
      .getByText(sku, { exact: true })
      .filter({ visible: true })
      .first()
      .isVisible({ timeout: 2_000 })
      .catch(() => false);
  }

  /**
   * APEX sometimes shows a blocking error after listing → detail navigation.
   * Dismiss via OK so the flow can recover (home → search again).
   */
  async dismissNavigateHomeSearchAgainIfVisible(): Promise<boolean> {
    const heading = this.page.getByRole('heading', {
      name: /Kindly navigate to home and search again/i,
    });
    if (!(await heading.isVisible({ timeout: 3_000 }).catch(() => false))) {
      return false;
    }

    const okButton = this.page
      .getByRole('button', { name: 'OK' })
      .filter({ visible: true })
      .first();
    await okButton.click();
    await heading.waitFor({ state: 'hidden', timeout: 15_000 }).catch(() => {});
    await this.page.waitForLoadState('domcontentloaded').catch(() => {});
    return true;
  }

  /** Best Deal grid links use discount-product-details-all-store; goto avoids repeat click errors. */
  private async gotoListingProductDetail(sku: string, href?: string | null): Promise<void> {
    const link = this.listingProductLinkForSku(sku);
    const detailHref = href ?? (await link.getAttribute('href'));
    if (!detailHref) {
      throw new Error(`V3: No product detail href found in listing for SKU ${sku}`);
    }

    const detailUrl = new URL(detailHref, this.page.url()).href;
    await this.page.goto(detailUrl, { waitUntil: 'domcontentloaded' });
    await this.dismissNavigateHomeSearchAgainIfVisible();
  }

  private async assertProductDetailNavigation(sku: string, context: string): Promise<void> {
    await expect(this.page, `${context}: Product detail URL should load for SKU ${sku}`).toHaveURL(
      this.productDetailUrlPattern,
      { timeout: 30_000 }
    );
    await expect(this.page, `${context}: Product detail URL should reference SKU ${sku}`).toHaveURL(
      this.skuInUrlPattern(sku),
      { timeout: 30_000 }
    );
  }

  /**
   * Open Best Deal product detail: try listing click first, then direct URL navigation
   * when APEX shows "navigate to home and search again".
   */
  private async openBestDealProductDetail(sku: string): Promise<void> {
    const productDetailLink = this.listingProductLinkForSku(sku);
    await expect(
      productDetailLink,
      `V3: Filtered listing should have one visible product link for SKU ${sku}`
    ).toBeVisible({ timeout: 30_000 });

    const detailHref = await productDetailLink.getAttribute('href');
    await productDetailLink.click();
    await this.page.waitForLoadState('domcontentloaded').catch(() => {});

    if (await this.dismissNavigateHomeSearchAgainIfVisible()) {
      await this.gotoListingProductDetail(sku, detailHref);
    } else if (!(await this.isOnProductDetailForSku(sku))) {
      await this.gotoListingProductDetail(sku, detailHref);
    }

    if (await this.dismissNavigateHomeSearchAgainIfVisible()) {
      await this.recoverListingProductDetailViaBestDeal(sku);
      return;
    }

    await this.assertProductDetailNavigation(sku, 'V3');
  }

  /** Flow 2: home → Best Deal → search → direct navigation to product detail. */
  private async recoverListingProductDetailViaBestDeal(sku: string): Promise<void> {
    await this.clickHomeMenu();
    await expect(this.page, 'Recovery: Home menu should return to home').toHaveURL(/home/, {
      timeout: 30_000,
    });
    await this.openBestDealFromHome();
    await this.assertBestDealPage();
    await this.searchSkuInListing(sku);
    await this.gotoListingProductDetail(sku);

    if (await this.dismissNavigateHomeSearchAgainIfVisible()) {
      throw new Error(
        `V3: Product detail could not load for SKU ${sku} — navigate-home error after direct navigation`
      );
    }

    await this.assertProductDetailNavigation(sku, 'Recovery');
  }

  async openOnlyFilteredProductFromListing(sku: string): Promise<void> {
    await this.openBestDealProductDetail(sku);
  }

  async assertProductDetailForSku(sku: string): Promise<void> {
    if (await this.dismissNavigateHomeSearchAgainIfVisible()) {
      if (await this.listingResultsRegion.isVisible().catch(() => false)) {
        await this.gotoListingProductDetail(sku);
      } else {
        await this.recoverListingProductDetailViaBestDeal(sku);
      }
    } else if (!(await this.isOnProductDetailForSku(sku))) {
      await this.openBestDealProductDetail(sku);
    }

    const escapedSku = sku.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    await expect(this.page, `V3: Product detail URL should reference SKU ${sku}`).toHaveURL(
      new RegExp(escapedSku),
      { timeout: 30_000 }
    );
    await expect(this.page, `V3: Product detail page should be loaded for SKU ${sku}`).toHaveURL(
      this.productDetailUrlPattern,
      { timeout: 10_000 }
    );
    await expect(
      this.page.getByText(sku, { exact: true }).filter({ visible: true }).first(),
      `V4: Product detail should show same SKU ${sku}`
    ).toBeVisible();
    const standardHeading = this.byKey('productDetailHeading');
    if (await standardHeading.isVisible().catch(() => false)) {
      await expect(standardHeading, `V3: Product detail heading should be visible for SKU ${sku}`).toBeVisible();
      await expect(this.byKey('skuLabel'), `V4: SKU label should be visible for SKU ${sku}`).toBeVisible();
    }
  }

  async openListingProductByLinkName(linkName: string): Promise<void> {
    const link = this.page.getByRole('link', { name: linkName }).first();
    await expect(link, `Flow 4: Listing link "${linkName}" should be visible`).toBeVisible({
      timeout: 30_000,
    });
    await link.click();
    await expect(this.page, 'Flow 4: Listing link should open product detail page').toHaveURL(
      /product-detail/,
      { timeout: 30_000 },
    );
  }

  async getSkuFromProductDetail(): Promise<string> {
    const productDetail = this.page.getByRole('region', { name: 'Product Detail' });
    await expect(productDetail, 'Flow 4: Product Detail region should be visible').toBeVisible({
      timeout: 20_000,
    });

    const skuContainer = this.byKey('productSkuField');
    await expect(skuContainer, 'Flow 4: Product SKU container (#P5_PRODUCT) should be visible').toBeVisible({
      timeout: 20_000,
    });

    let sku = '';
    const editableField = skuContainer.locator('input, textarea, select');
    if (await editableField.count()) {
      sku = (await editableField.first().inputValue()).trim();
    }

    if (!sku) {
      // APEX renders #P5_PRODUCT as a display-only container with the SKU as text.
      const containerText = (await skuContainer.innerText()).trim();
      sku = containerText.match(/\b[A-Z0-9]{14}\b/)?.[0] ?? '';
    }

    if (!sku) {
      const candidates = this.parseSkuCandidates(await productDetail.innerText());
      sku = candidates.find((value) => value.length === 14) ?? candidates[0] ?? '';
    }

    if (!/^[A-Z0-9]{14}$/.test(sku)) {
      throw new Error(
        `Flow 4: Item Search requires a 14-character SKU from product detail; got "${sku}"`,
      );
    }

    await expect(
      productDetail.getByText(sku, { exact: true }),
      `Flow 4: Product Detail should display fetched SKU ${sku}`,
    ).toBeVisible({ timeout: 10_000 });

    return sku;
  }

  async openAllProductsFromHome(): Promise<void> {
    await this.byKey('allProductsTile').click();
  }

  async assertAllProductCategories(categories: readonly string[]): Promise<void> {
    for (const c of categories) {
      await expect.soft(this.page.getByRole('link', { name: c }), `V2: Category "${c}" should be visible`).toBeVisible();
    }
  }

  async selectCategory(categoryName: string): Promise<void> {
    await this.page.getByRole('link', { name: categoryName }).first().click();
  }

  async assertSideColumnVisible(): Promise<void> {
    await expect(this.byKey('sideColumnToggle'), 'V2.1.1: Side column toggle should be visible').toBeVisible();
  }

  async assertProductFilterContains(categoryName: string): Promise<void> {
    const currentFilters = this.page.locator('.a-FS-currentList[aria-label="Current filters"]');
    await expect(currentFilters.locator('.a-FS-currentLabel', { hasText: /^Product$/ }), 'V2.1.2: Product filter label should be visible').toBeVisible();
    await expect(currentFilters.getByRole('button', { name: `Clear Product ${categoryName}` }), `V2.1.2: Product filter value should include ${categoryName}`).toBeVisible();
  }

  async clickSkipAndContinueIfVisible(): Promise<void> {
    const btn = this.byKey('skipAndContinueButton');
    if (await btn.isVisible().catch(() => false)) {
      await btn.click();
      await this.page.waitForLoadState('domcontentloaded').catch(() => {});
    }
  }

  async assertBrandAndCategoryFiltersAfterSkip(categoryName: string): Promise<void> {
    const currentFilters = this.page.locator('.a-FS-currentList[aria-label="Current filters"]');
    await expect(currentFilters, 'V2.2.1: Current filters region should be visible').toBeVisible();
    await expect(currentFilters.locator('.a-FS-currentLabel', { hasText: /^Brand$/ }), 'V2.2.1: Brand filter should be present after skip & continue').toBeVisible();
    await expect(currentFilters.getByRole('button', { name: /Clear Brand/i }), 'V2.2.1: Brand value should be selected after skip & continue').toBeVisible();
    await expect(currentFilters.locator('.a-FS-currentLabel', { hasText: /^Product$/ }), 'V2.2.1: Product filter should remain after skip & continue').toBeVisible();
    await expect(currentFilters.getByRole('button', { name: `Clear Product ${categoryName}` }), `V2.2.1: Product filter should still be ${categoryName} after skip & continue`).toBeVisible();
  }

  async toggleSortLowToHigh(): Promise<void> {
    await this.byKey('lowToHighButton').click();
    await this.waitForListingPricesStable();
  }

  async getTopApproxPrices(limit: number): Promise<number[]> {
    await this.waitForListingPricesStable(limit);
    const raw = await this.approxPriceLocator().allTextContents();
    const parsed = raw
      .map((t) => {
        const m = t.match(/₹\s*([\d,]+)\s*Approx\./);
        return m ? Number(m[1].replace(/,/g, '')) : NaN;
      })
      .filter((n) => Number.isFinite(n));
    return parsed.slice(0, limit);
  }

  assertAscending(values: number[], label: string): void {
    if (values.length < 3) {
      throw new Error(`${label}: Not enough price values to compare first 3 products.`);
    }
    expect(values[0], `${label}: first price should be <= second (${values[0]} <= ${values[1]})`).toBeLessThanOrEqual(values[1]);
    expect(values[1], `${label}: second price should be <= third (${values[1]} <= ${values[2]})`).toBeLessThanOrEqual(values[2]);
  }

  assertDescending(values: number[], label: string): void {
    if (values.length < 3) {
      throw new Error(`${label}: Not enough price values to compare first 3 products.`);
    }
    expect(values[0], `${label}: first price should be >= second (${values[0]} >= ${values[1]})`).toBeGreaterThanOrEqual(values[1]);
    expect(values[1], `${label}: second price should be >= third (${values[1]} >= ${values[2]})`).toBeGreaterThanOrEqual(values[2]);
  }

  async selectProductsForExport(count: number): Promise<string[]> {
    const shareButtons = this.page.locator('[id$="_share"]');
    const selected: string[] = [];
    const total = await shareButtons.count();
    for (let i = 0; i < total && selected.length < count; i++) {
      const btn = shareButtons.nth(i);
      const id = await btn.getAttribute('id');
      if (!id || !id.endsWith('_share')) continue;
      const sku = id.replace(/_share$/, '');
      if (!sku) continue;
      await btn.click();
      await expect(this.exportSelectedButton(sku).first(), `V4: SKU ${sku} should show selected state`).toBeVisible({
        timeout: 15_000,
      });
      selected.push(sku);
    }
    return selected;
  }

  async assertAddedToExportList(sku: string): Promise<void> {
    await expect(this.byKey('exportListHeading'), 'V4: Export List heading should be visible').toBeVisible();
    await expect(this.exportSelectedButton(sku).first(), `V4: SKU ${sku} should remain selected in export list`).toBeVisible({
      timeout: 15_000,
    });
    await expect(
      this.listingProductLinkForSku(sku),
      `V4: Added SKU ${sku} should remain on the listing grid`
    ).toBeVisible({ timeout: 15_000 });
  }

  async unselectProductsFromExport(skus: string[]): Promise<void> {
    for (const sku of skus) {
      const selectedBtn = this.exportSelectedButton(sku);
      if (await selectedBtn.count()) {
        await selectedBtn.first().click();
        await expect(selectedBtn.first(), `V6: SKU ${sku} should deselect after toggle`).toBeHidden({ timeout: 15_000 });
      }
    }
  }

  async assertRemovedFromExportList(sku: string): Promise<void> {
    await expect(this.exportSelectedButton(sku).first(), `V6: SKU ${sku} should no longer be selected in export list`).toBeHidden({
      timeout: 15_000,
    });
  }

  async shareViaWhatsApp(data: { customerName: string; mobile: string; rsoName: string; purpose: string }): Promise<void> {
    await this.byKey('shareButton').click();
    await this.byKey('shareViaWhatsApp').click();
    await this.byKey('customerName').fill(data.customerName);
    await this.byKey('mobileNumber').fill(data.mobile);
    await this.byKey('rsoName').fill(data.rsoName);
    await this.page.getByLabel('Purpose').selectOption(data.purpose);
    await this.byKey('sendButton').click();
    await expect(this.byKey('exportListHeading'), 'V7: Export list should remain visible after WhatsApp share').toBeVisible();
  }

  async shareViaPdf(
    customerName = 'Test Customer',
    mobileNumber = '9999999999',
    rsoName      = 'Test RSO',
  ): Promise<void> {
    await this.byKey('shareButton').click();
    await this.byKey('shareViaPdf').click();

    // Dismiss any immediate blocking alert before doing anything else
    const confirmation = this.page.getByRole('alertdialog', { name: 'Confirmation' });
    if (await confirmation.isVisible({ timeout: 3_000 }).catch(() => false)) {
      const message = await confirmation.innerText().catch(() => 'confirmation required');
      await confirmation.getByRole('button', { name: 'OK' }).click();
      throw new Error(`V7: PDF catalogue share pre-blocked — ${message}`);
    }

    // "Enter Details" dialog MUST be filled before Download is clicked.
    // Use waitFor() — isVisible() does NOT wait for an element to appear.
    const enterDetailsDialog = this.page.getByRole('dialog', { name: 'Enter Details' });
    const dialogVisible = await enterDetailsDialog
      .waitFor({ state: 'visible', timeout: 15_000 })
      .then(() => true)
      .catch(() => false);

    if (dialogVisible) {
      await enterDetailsDialog.getByRole('textbox', { name: 'Customer Name *' }).fill(customerName);
      await enterDetailsDialog.getByRole('textbox', { name: 'Mobile Number *' }).fill(mobileNumber);
      await enterDetailsDialog.getByRole('textbox', { name: 'RSO Name *' }).fill(rsoName);

      // Assert all three fields are non-empty before clicking Download
      await expect(
        enterDetailsDialog.getByRole('textbox', { name: 'Customer Name *' }),
        'V7: Customer Name must be filled before Download',
      ).not.toBeEmpty();
      await expect(
        enterDetailsDialog.getByRole('textbox', { name: 'Mobile Number *' }),
        'V7: Mobile Number must be filled before Download',
      ).not.toBeEmpty();
      await expect(
        enterDetailsDialog.getByRole('textbox', { name: 'RSO Name *' }),
        'V7: RSO Name must be filled before Download',
      ).not.toBeEmpty();
    }

    // Now wait for and click Download
    const downloadBtn = this.byKey('downloadButton');
    await expect(downloadBtn, 'V7: Download button should be visible after filling details').toBeVisible({
      timeout: 10_000,
    });
    const popupPromise = this.page.waitForEvent('popup', { timeout: 15_000 }).catch(() => null);
    await downloadBtn.click();

    // Catch post-click validation alert (e.g. a field was silently rejected)
    if (await confirmation.isVisible({ timeout: 3_000 }).catch(() => false)) {
      await confirmation.getByRole('button', { name: 'OK' }).click();
      throw new Error('V7: PDF download blocked — mandatory fields were not accepted by the app');
    }

    const popup = await popupPromise;
    if (popup) await popup.close().catch(() => {});
  }

  async openItemSearchFromHome(): Promise<void> {
    await this.byKey('itemSearchTile').click();
    await this.ensureItemSearchPage();
  }

  private async ensureItemSearchPage(): Promise<void> {
    if (!this.page.url().includes('product-detail-item-search')) {
      await this.page.goto(`${BASE_URL}product-detail-item-search`);
    }
    await expect(this.byKey('itemSearchInput'), 'Flow 4: Item search input should be visible').toBeVisible({
      timeout: 20_000,
    });
  }

  private async dismissIncompleteItemCodeAlert(): Promise<boolean> {
    const alertTitle = this.page.getByRole('heading', {
      name: /Kindly provide the full Item code/i,
    });

    if (!(await alertTitle.isVisible({ timeout: 3_000 }).catch(() => false))) {
      return false;
    }

    await this.page.locator('button.a-Error-back', { hasText: 'OK' }).click();
    await expect(this.byKey('itemSearchInput'), 'Flow 4: Item search should be visible after closing validation alert')
      .toBeVisible({ timeout: 20_000 });
    return true;
  }

  async searchItemCode(code: string): Promise<void> {
    await this.ensureItemSearchPage();

    for (let attempt = 1; attempt <= 2; attempt += 1) {
      // Dismiss any open nav dropdown that could overlay the Search button.
      await this.page.keyboard.press('Escape');

      const input = this.byKey('itemSearchInput');
      await input.clear();
      await input.fill(code);
      // Press Enter on the input — more reliable than clicking the Search button
      // because it bypasses any nav overlay and fires after APEX's input handler.
      await input.press('Enter');

      if (!(await this.dismissIncompleteItemCodeAlert())) {
        break;
      }

      if (attempt === 2) {
        throw new Error(`Flow 4: Item search kept showing incomplete item-code alert for SKU ${code}`);
      }
    }

    const errorRegion = this.page.getByRole('region', { name: 'Error Message' });
    if (await errorRegion.waitFor({ state: 'visible', timeout: 3_000 }).then(() => true).catch(() => false)) {
      const message = await errorRegion.innerText().catch(() => 'Item search validation failed');
      throw new Error(`Flow 4: Item search rejected SKU ${code} — ${message}`);
    }

    // The item search page uses APEX partial refresh — p6_sku in the URL is
    // only set on the FIRST search of the session and does NOT update on
    // subsequent searches. Assert on the unique h2 heading instead of the
    // region (APEX renders two overlapping region roles for the same widget).
    await expect(
      this.page.getByRole('heading', { name: /Stock Availability/i, level: 2 }),
      `Flow 4: Stock Availability heading should appear after searching SKU ${code}`,
    ).toBeVisible({ timeout: 30_000 });
  }

  async selectSkuFromItemSearch(sku: string): Promise<void> {
    // On the item search page the product is already shown after searchItemCode().
    // The only a[href*=sku] links are product image thumbnails — clicking them
    // opens a lightbox, not a product detail page. Close the lightbox if open,
    // then confirm we are on the correct page.
    const lightboxClose = this.page.locator('.fancybox-close, .fancybox-button--close, [aria-label="Close"], button.t-Dialog-close')
      .filter({ visible: true })
      .first();
    if (await lightboxClose.isVisible().catch(() => false)) {
      await lightboxClose.click();
      await lightboxClose.waitFor({ state: 'hidden', timeout: 5_000 }).catch(() => {});
    }

    // Verify the correct SKU's stock availability is shown
    await expect(
      this.page.getByRole('heading', { name: /Stock Availability/i, level: 2 }),
      `Flow 4: Item search result page should show Stock Availability for SKU ${sku}`,
    ).toBeVisible({ timeout: 15_000 });
  }

  async selectCustomerForWithoutPayment(mobile: string, expectedName: string): Promise<void> {
    const selectCustomerButton = this.byKey('withoutPaymentSelectButton');

    if (!(await selectCustomerButton.isVisible({ timeout: 60_000 }).catch(() => false))) {
      await this.page.reload({ waitUntil: 'domcontentloaded' });
      await expect(
        this.page.getByRole('heading', { name: /Stock Availability/i, level: 2 }),
        'Flow 4: Stock Availability should be visible after refreshing item search result',
      ).toBeVisible({ timeout: 60_000 });
    }

    if (!(await selectCustomerButton.isVisible({ timeout: 60_000 }).catch(() => false))) {
      const stockText = await this.page.getByRole('region', { name: /Stock Availability/i })
        .last()
        .innerText({ timeout: 5_000 })
        .catch(() => '');

      if (/sold out|no stock available/i.test(stockText)) {
        throw new Error(
          'Flow 4: SKU is sold out / no stock is available, so "Select Customer to Book" is not shown. ' +
          'Use a SKU that has store or factory stock for the without-payment booking flow.',
        );
      }

      await expect(
        selectCustomerButton,
        'Flow 4: Select Customer to Book button should be visible before customer selection',
      ).toBeVisible({ timeout: 60_000 });
    }

    await selectCustomerButton.click();
    const customerFrame = this.page.frameLocator('iframe[title="Customer"]');
    await customerFrame.getByRole('textbox', { name: 'Enter Customer Mobile #' }).fill(mobile);
    await customerFrame.getByRole('button', { name: 'Search' }).click();
    await expect(
      customerFrame.getByText(expectedName),
      `Flow 4: Customer modal should show searched customer name "${expectedName}"`
    ).toBeVisible({ timeout: 20_000 });

    // Clicking OK triggers a full APEX page navigation — fire-and-wait together
    // so the old page context is not torn down before the new one is ready.
    await Promise.all([
      this.page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30_000 }).catch(() => {}),
      customerFrame.getByRole('button', { name: 'OK' }).click(),
    ]);

    // After navigation the stock table re-renders — wait before next step
    await expect(
      this.page.getByRole('heading', { name: /Stock Availability/i, level: 2 }),
      'Flow 4: Stock Availability should reappear after customer selection',
    ).toBeVisible({ timeout: 30_000 });
  }

  async bookFactoryWithoutPayment(reason: string): Promise<void> {
    await this.byKey('withoutPaymentBookFactoryButton').click();
    const frame = this.page.frameLocator('iframe[title="Factory Request"]');
    await expect(frame.getByText('Yes'), 'Flow 4: Factory request modal should show Yes option').toBeVisible();
    await expect(frame.getByText('No', { exact: true }), 'Flow 4: Factory request modal should show No option').toBeVisible();
    await frame.getByRole('radio', { name: 'No' }).check();
    await frame.getByLabel('Reason').selectOption(reason);
    await frame.getByText('I confirm and proceed forward').click();
    await frame.getByRole('button', { name: 'Confirm' }).click();
  }

  async assertOrderDetailsAfterPoss(sku: string, customerName: string): Promise<void> {
    await this.byKey('withoutPaymentPossButton').click();

    const orderDialog = this.page.getByRole('dialog', { name: 'Order Details' });
    await expect(orderDialog, 'Flow 4: Order Details dialog should be visible').toBeVisible({
      timeout: 20_000,
    });

    // APEX renders order fields inside an iframe within the dialog shell.
    const orderFrame = orderDialog.frameLocator('iframe');
    await expect(
      orderFrame.getByText(sku, { exact: true }),
      `Flow 4: Order details should show SKU ${sku}`,
    ).toBeVisible({ timeout: 15_000 });
    await expect(
      orderFrame.getByText(customerName, { exact: true }),
      `Flow 4: Order details should show customer ${customerName}`,
    ).toBeVisible({ timeout: 10_000 });

    await orderDialog.getByRole('button', { name: 'Close' }).click();
    await orderDialog.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }
}

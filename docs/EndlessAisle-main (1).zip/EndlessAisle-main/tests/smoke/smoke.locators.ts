export const HOME_LOCATORS = {
  navigationLabel: 'Navigation',
  userButtonRegex: /TEST_EA/i,
  signOutName: 'Sign Out',
  tileLinkPrefix: 'Card Image ',
  tileImageName: 'Card Image',
};

/**
 * Simple key-value locator map.
 * Format:
 *   role=<role>|<name>
 *   text=<visible text>
 *   css=<css selector>
 */
export const LOCATORS = {
  loginUsername: 'role=textbox|Username',
  loginPassword: 'role=textbox|Password',
  loginButton: 'role=button|LOGIN ›',

  itemSearchHeading: 'css=#R23471834620407112_heading',
  rivaahMenuItem: 'role=menuitem|Rivaah',
  customerOrderHeading: 'role=heading|Customer Order Management',
  brandInCurrentFilters: 'text=BRAND',
  smartImageSearchHeading: 'css=#search-with-image_heading',
  itemSearchTextbox: 'role=textbox|Item Search [ Enter 14 digit',
  lotNumberTextbox: 'role=textbox|LOT Number',
  estimationSlipHeading: 'css=#R28416661007795401_heading',
  solitaireUinHeading: 'css=#R924688565586912713_heading',
  goldKaratageHeading: 'role=heading|Gold Karatage',
  makeOwnCatalogueButton: 'role=button|Make your own catalogue',
  ibtHeading: 'role=heading|Inter Boutique Transfer',
  customerWishlistText: 'text=Customer with Wishlist Items',
  silverCollectionsFormItem: 'css=.t-Form-itemWrapper',
  browseStoreStockPopupText: 'text=Welcome to TBO.. Please Scan',
  scanButton: 'role=button|Scan',
  shubhGoldText: 'text=SHUBH GOLD EXPRESS',
  homeDeliveryText: 'text=HomeHome Delivery Breadcrumb',
  chatbotText: 'text=GenAI Agents for APEX Inbuilt',

  homeMenuItem: 'role=menuitem|Home',
  allProductsMenuItem: 'role=menuitem|All Products',
  bestDealMenuItem: 'role=menuitem|Best Deal',

  listingSearch: 'role=searchbox|Search',
  productDetailHeading: 'role=heading|Product Detail -',
  productSkuField: 'css=#P5_PRODUCT',
  skuLabel: 'text=SKU',
  stockAvailabilityHeading: 'role=heading|Stock Availability [',

  allProductsTile: 'role=link|Card Image All Products',
  earringsCategory: 'role=link|Earrings',
  banglesCategory: 'role=link|Bangles',
  mangalsutraCategory: 'role=link|Mangalsutra',
  fingerRingsCategory: 'role=link|Finger Rings',
  chainsCategory: 'role=link|Chains',
  necklaceCategory: 'role=link|Necklace',
  othersCategory: 'role=link|Others',

  sideColumnToggle: 'role=button|Expand / Collapse Side Column',
  currentFiltersRegion: 'text=Current filters',
  productFilterLabel: 'text=Product',
  skipAndContinueButton: 'role=button|Skip & Continue',
  lowToHighButton: 'role=button|💰 Low to High',

  exportListHeading: 'role=heading|Export List',
  closeNotification: 'text=Close Notification',

  shareButton: 'css=#shareBtn',
  shareViaWhatsApp: 'role=listitem|Share via WhatsApp',
  shareViaPdf: 'role=listitem|Make your own Catalogue',
  customerName: 'role=textbox|Customer Name *',
  mobileNumber: 'role=textbox|Mobile Number *',
  rsoName: 'role=textbox|RSO Name *',
  purposeDropdown: 'css=select[aria-label="Purpose"]',
  sendButton: 'role=button|Send',
  cancelButton: 'role=button|Cancel',
  downloadButton: 'role=button|Download',

  itemSearchTile: 'role=link|Card Image Item Search',
  itemSearchInput: 'role=textbox|Enter item code or scan The QR',
  genericSearchButton: 'role=button|Search',
  withoutPaymentSelectButton: 'role=button|Select Customer to Book',
  withoutPaymentBookFactoryButton: 'role=button|Book Factory Stock',
  withoutPaymentPossButton: 'css=.btn-active[data-action*="pageId=44"]',
  customerMobileInput: 'role=textbox|Enter Customer Mobile #',
  customerSearchButton: 'role=button|Search',
  customerOkButton: 'role=button|OK',
  factoryNoRadio: 'role=radio|No',
  factoryReasonDropdown: 'text=Reason',
  factoryConfirmNote: 'text=I confirm and proceed forward',
  factoryConfirmButton: 'role=button|Confirm',
  orderDetailsMain: 'role=main|',
  orderDetailsClose: 'role=button|Close',
} as const;

export type LocatorKey = keyof typeof LOCATORS;

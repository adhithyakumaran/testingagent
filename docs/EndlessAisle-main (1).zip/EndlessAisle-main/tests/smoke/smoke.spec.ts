/**
 * Endless Aisle — Home Navigation Hub
 *
 * Single end-to-end flow covering:
 *   V0  Login page fields and successful landing
 *   V1  Home page loads with full tile grid
 *   V2  Tile count = 28
 *   V3  All tile names are correct
 *   V4  Every tile has a card image
 *   V5  Tiles appear in the expected order
 *   V6  Each tile navigates to its target page
 */

import { expect } from '@playwright/test';
import { test } from './incognito.fixture';
import { SmokePage } from './smoke.page';
import { FLOW2, FLOW3, FLOW4, HOME_TILES, EXPECTED_TILE_COUNT, EXPECTED_TILE_NAMES } from './smoke.data';

test.describe('Smoke suite', { tag: '@smoke' }, () => {
test('Smoke Flow 1 - Endless Aisle — Home Navigation Hub', async ({ page }) => {
  test.setTimeout(300_000); // 5 min for 28 tile navigations

  // ── V0: Login page verification and login ────────────────────────────────
  // Checks login URL/fields/button, fills credentials, lands on home
  const smoke = new SmokePage(page);
  await smoke.login();
  const homeUrl = page.url();

  // ── V1: Home page ────────────────────────────────────────────────────────
  await expect(page, 'V1: Post-login URL should contain "home"').toHaveURL(/home/);
  await expect(smoke.navTileList, 'V1: Home tile grid should be visible').toBeVisible();
  await expect(smoke.userMenuButton, 'V1: Logged-in user menu should be visible').toBeVisible();

  // ── V2: Tile count ───────────────────────────────────────────────────────
  expect(
    HOME_TILES.length,
    `V2: Static smoke data should contain exactly ${EXPECTED_TILE_COUNT} tiles`
  ).toBe(EXPECTED_TILE_COUNT);
  const actualTileCount = await smoke.getTileCount();
  expect.soft(
    actualTileCount,
    `V2: Home page should show exactly ${EXPECTED_TILE_COUNT} tiles, but found ${actualTileCount}`
  ).toBe(EXPECTED_TILE_COUNT);

  // ── V3: All tile names present ───────────────────────────────────────────
  for (const name of EXPECTED_TILE_NAMES) {
    await expect.soft(smoke.tileHeading(name), `V3: Tile heading "${name}" should be visible`).toBeVisible();
  }

  // ── V4: All tile images present ──────────────────────────────────────────
  for (const name of EXPECTED_TILE_NAMES) {
    await expect.soft(smoke.tileImage(name), `V4: Tile image for "${name}" should be visible`).toBeVisible();
  }

  // ── V5: Tiles in expected order ──────────────────────────────────────────
  const actualTileNames = await smoke.getTileNames();
  expect.soft(
    actualTileNames,
    `V5: Tile order mismatch.\nExpected: ${EXPECTED_TILE_NAMES.join(' | ')}\nActual: ${actualTileNames.join(' | ')}`
  ).toEqual(EXPECTED_TILE_NAMES);

  // ── V6: Each tile navigates to the correct page ──────────────────────────
  for (const tile of HOME_TILES) {
    try {
      await smoke.verifyTileNavigation(tile, homeUrl);
    } catch (err) {
      // Record the failure but continue checking remaining tiles
      const msg = err instanceof Error ? err.message : String(err);
      expect.soft(false, `V6: Tile "${tile.name}" failed navigation/assertion.\n${msg}`).toBeTruthy();
      try {
        await smoke.goHome(homeUrl);
      } catch {
        // best effort to continue the loop
      }
    }
  }

  // ── Logout ───────────────────────────────────────────────────────────────
  await smoke.logout();
});

test('Smoke Flow 2 — Best Deal random SKU search and detail validation', async ({ page }) => {
  test.setTimeout(240_000);
  const smoke = new SmokePage(page);

  // V0
  await smoke.login();
  await expect(page, 'V0: After login, URL should contain home').toHaveURL(/home/);

  // V1
  await smoke.clickHomeMenu();
  await expect(page, 'V1: Home menu click should keep user on home context').toHaveURL(/home/);

  // V2
  await smoke.openBestDealFromHome();
  await smoke.assertBestDealPage();

  // V3 + V4
  expect(FLOW2.staticSku, 'V3: Static SKU must match configured SKU pattern').toMatch(FLOW2.skuPattern);
  await smoke.searchSkuInListing(FLOW2.staticSku);
  await smoke.openOnlyFilteredProductFromListing(FLOW2.staticSku);
  await smoke.assertProductDetailForSku(FLOW2.staticSku);
});

test('Smoke Flow 3 — All Products category, sorting, export, WhatsApp and PDF share', async ({ page }) => {
  test.setTimeout(300_000);
  const smoke = new SmokePage(page);

  // V0 + V1
  await smoke.login();
  await smoke.clickHomeMenu();
  await expect(page, 'V1: Home menu should be visible after login').toHaveURL(/home/);

  // V2
  await smoke.openAllProductsFromHome();
  await smoke.assertAllProductCategories(FLOW3.categories);

  // V2.1.0 / V2.1.1 / V2.1.2
  await smoke.selectCategory(FLOW3.categoryToSelect);
  await smoke.assertSideColumnVisible();
  await smoke.assertProductFilterContains(FLOW3.categoryToSelect);

  // V2.2.0 / V2.2.1
  await smoke.clickSkipAndContinueIfVisible();
  await smoke.assertBrandAndCategoryFiltersAfterSkip(FLOW3.categoryToSelect);

  // V3
  await smoke.toggleSortLowToHigh();
  const firstLowToHigh = await smoke.getTopApproxPrices(3);
  smoke.assertAscending(firstLowToHigh, 'V3 Low to High');

  await smoke.toggleSortLowToHigh();
  const firstHighToLow = await smoke.getTopApproxPrices(3);
  smoke.assertDescending(firstHighToLow, 'V3 High to Low');

  // V4
  const selectedSkus = await smoke.selectProductsForExport(FLOW3.shareCount);
  expect(selectedSkus.length, `V4: Should select at least ${FLOW3.shareCount} products for export`).toBeGreaterThanOrEqual(FLOW3.shareCount);
  await smoke.assertAddedToExportList(selectedSkus[0]);

  // V5
  await smoke.openSkuFromListing(selectedSkus[0]);
  await smoke.assertProductDetailForSku(selectedSkus[0]);
  await smoke.page.goBack();

  // V6
  await smoke.unselectProductsFromExport(selectedSkus);
  await smoke.assertRemovedFromExportList(selectedSkus[0]);

  // V7 (WhatsApp + PDF)
  const reSelected = await smoke.selectProductsForExport(1);
  await smoke.shareViaWhatsApp(FLOW3.whatsapp);
  // WhatsApp send clears the export basket — add a product again before PDF share.
  await smoke.selectProductsForExport(1);
  await smoke.shareViaPdf();

  // Logout
  await smoke.logout();
  expect(reSelected.length, 'V7: At least one product should be selected before sharing').toBeGreaterThan(0);
});

test('Smoke Flow 4 — Item Search, customer selection, factory booking and POSS order details', async ({ page }) => {
  test.setTimeout(300_000);
  const smoke = new SmokePage(page);

  // V0
  await smoke.login();
  await expect(page, 'V0: After login, URL should contain home').toHaveURL(/home/);

  // V1
  await smoke.clickHomeMenu();

  // V2 — discover SKU from All Products before Item Search
  await smoke.openAllProductsFromHome();
  await smoke.selectCategory(FLOW4.category);
  await smoke.clickSkipAndContinueIfVisible();
  await smoke.openListingProductByLinkName(FLOW4.listingLinkName);
  const discoveredSku = await smoke.getSkuFromProductDetail();

  // V3 + V4 — Item Search using discovered SKU
  await smoke.clickHomeMenu();
  await smoke.openItemSearchFromHome();
  await smoke.searchItemCode(discoveredSku);
  await smoke.searchItemCode(discoveredSku);
  await smoke.selectSkuFromItemSearch(discoveredSku);

  // Customer selection flow
  await smoke.selectCustomerForWithoutPayment(FLOW4.customerMobile, FLOW4.expectedCustomerName);

  // Factory booking flow
  await smoke.bookFactoryWithoutPayment(FLOW4.factoryReason);

  // POSS / order details flow
  await smoke.assertOrderDetailsAfterPoss(discoveredSku, FLOW4.expectedCustomerName);
});
});

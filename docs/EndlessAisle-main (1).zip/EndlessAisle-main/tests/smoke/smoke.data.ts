import type { LocatorKey } from './smoke.locators';

export interface TileData {
  name: string;
  opensNewTab?: boolean;
  assertType: 'urlIncludes' | 'visible' | 'containsText';
  locatorKey?: LocatorKey;
  assertValue: string;
}

export const HOME_TILES: TileData[] = [
  { name: 'All Products', assertType: 'urlIncludes', assertValue: 'select-category' },
  {
    name: 'Item Search',
    assertType: 'containsText',
    locatorKey: 'itemSearchHeading',
    assertValue: 'Product Search',
  },
  { name: 'Rivaah', assertType: 'visible', locatorKey: 'rivaahMenuItem', assertValue: 'Rivaah' },
  { name: 'Customer Order', assertType: 'visible', locatorKey: 'customerOrderHeading', assertValue: 'Customer Order' },
  { name: 'Best Deal', assertType: 'visible', locatorKey: 'brandInCurrentFilters', assertValue: 'BRAND' },
  {
    name: 'Smart Image Search',
    assertType: 'containsText',
    locatorKey: 'smartImageSearchHeading',
    assertValue: 'Search With Image',
  },
  { name: 'ECOM Stock Visibility', assertType: 'visible', locatorKey: 'itemSearchTextbox', assertValue: 'Item Search' },
  { name: 'Find Price', assertType: 'visible', locatorKey: 'lotNumberTextbox', assertValue: 'LOT Number' },
  {
    name: 'Estimation Slip',
    assertType: 'containsText',
    locatorKey: 'estimationSlipHeading',
    assertValue: 'Estimation Slip',
  },
  {
    name: 'Solitaire UIN',
    assertType: 'containsText',
    locatorKey: 'solitaireUinHeading',
    assertValue: 'UIN Search',
  },
  { name: 'Gold Coin Stock Visibility', assertType: 'visible', locatorKey: 'goldKaratageHeading', assertValue: 'Gold Karatage' },
  { name: 'Stock Visibility', assertType: 'visible', locatorKey: 'itemSearchTextbox', assertValue: 'Item Search' },
  { name: 'My Store Stock', assertType: 'visible', locatorKey: 'makeOwnCatalogueButton', assertValue: 'Make your own catalogue' },
  { name: 'Open IBT Action - Urgent', assertType: 'visible', locatorKey: 'ibtHeading', assertValue: 'Inter Boutique Transfer' },
  { name: 'Report', assertType: 'urlIncludes', assertValue: 'order-tracking' },
  { name: 'Customer Wishlist', assertType: 'visible', locatorKey: 'customerWishlistText', assertValue: 'Customer with Wishlist Items' },
  { name: 'Solitaire Products', assertType: 'visible', locatorKey: 'brandInCurrentFilters', assertValue: 'BRAND' },
  { name: 'New Collections', assertType: 'visible', locatorKey: 'makeOwnCatalogueButton', assertValue: 'Make your own catalogue' },
  { name: 'High Value Studded', assertType: 'visible', locatorKey: 'makeOwnCatalogueButton', assertValue: 'Make your own catalogue' },
  { name: 'Silver Collections', assertType: 'urlIncludes', assertValue: 'silver-collections' },
  { name: 'Size Based Search', assertType: 'visible', locatorKey: 'itemSearchTextbox', assertValue: 'Item Search' },
  {
    name: 'Engagement -Min 7 Day Delivery',
    assertType: 'visible',
    locatorKey: 'makeOwnCatalogueButton',
    assertValue: 'Make your own catalogue',
  },
  { name: 'National/Regional Best Seller', assertType: 'urlIncludes', assertValue: 'national-best-seller' },
  {
    name: 'Browse Store Stock',
    opensNewTab: true,
    assertType: 'visible',
    locatorKey: 'browseStoreStockPopupText',
    assertValue: 'Welcome to TBO.. Please Scan',
  },
  { name: 'KVI&FMC', assertType: 'visible', locatorKey: 'scanButton', assertValue: 'Scan' },
  { name: 'Shubh Gold Express', assertType: 'visible', locatorKey: 'shubhGoldText', assertValue: 'SHUBH GOLD EXPRESS' },
  { name: 'Home Delivery', assertType: 'visible', locatorKey: 'homeDeliveryText', assertValue: 'HomeHome Delivery Breadcrumb' },
  { name: 'Chatbot', assertType: 'visible', locatorKey: 'chatbotText', assertValue: 'GenAI Agents for APEX Inbuilt' },
];

export const EXPECTED_TILE_COUNT = 28;
export const EXPECTED_TILE_NAMES = HOME_TILES.map((tile) => tile.name);

export const FLOW2 = {
  targetTile: 'Best Deal',
  staticSku: '512018FASAA00',
  skuPattern: /[0-9A-Z]{10,16}/,
} as const;

export const FLOW3 = {
  allProductsTile: 'All Products',
  categories: ['Earrings', 'Bangles', 'Mangalsutra', 'Finger Rings', 'Chains', 'Necklace', 'Others'],
  categoryToSelect: 'Earrings',
  shareCount: 3,
  whatsapp: {
    customerName: 'demo',
    mobile: '7898778883',
    rsoName: 'demo',
    purpose: 'FUTURE',
  },
} as const;

export const FLOW4 = {
  category: 'Earrings',
  listingLinkName: 'Elevate your everyday vibe',
  customerMobile: '8754481080',
  expectedCustomerName: 'Balamurugan H',
  factoryReason: 'NO_STOCK',
} as const;

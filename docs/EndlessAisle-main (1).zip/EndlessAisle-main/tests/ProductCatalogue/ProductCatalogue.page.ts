import { expect, type Page } from '@playwright/test';

export class ProductCataloguePage {
  constructor(readonly page: Page) {}

  /** Soft checks — failures appear in the report but the test keeps running. */
  async assertEarringsListingReady(): Promise<void> {
    await expect.soft(this.inputSearchKeyword).toBeVisible({ timeout: 30_000 });
    await expect.soft(this.inputSearchKeyword).toBeEnabled();
  }

  async assertProductDetailLoaded(): Promise<void> {
    await expect.soft(this.page).toHaveURL(/product-detail/, { timeout: 30_000 });
    await expect.soft(this.productDetailContent).toBeVisible();
  }

  async assertRemainsOnLogin(): Promise<void> {
    await expect.soft(this.page).toHaveURL(/login/);
    await expect.soft(this.inputUsername).toBeVisible();
  }

  // ── Page Navigation ───────────────────────────────────────────────────────────
  get pageTitle() {
    return this.page.getByRole('heading').first();
  }

  get linkAllProducts() {
    return this.page.getByRole('link', { name: 'Card Image All Products' });
  }

  get linkEarringsCategory() {
    return this.page.getByRole('link', { name: 'Earrings' });
  }

  // ── Login ─────────────────────────────────────────────────────────────────────
  get inputUsername() {
    return this.page.getByRole('textbox', { name: 'Username' });
  }

  get inputPassword() {
    return this.page.getByRole('textbox', { name: 'Password' });
  }

  get btnLogin() {
    return this.page.getByRole('button', { name: 'LOGIN ›' });
  }

  // ── Search & Filter ───────────────────────────────────────────────────────────
  get inputSearchKeyword() {
    return this.page.getByRole('textbox', { name: 'Enter keyword or scan' });
  }

  get btnSearch() {
    return this.page.getByRole('button', { name: 'Search', exact: true });
  }

  get btnSortLowToHigh() {
    return this.page.getByRole('button', { name: /Low to High|High to Low/i });
  }

  get headingBrand() {
    return this.page.getByRole('heading', { name: 'Brand' });
  }

  get headingAvailableAtFactory() {
    return this.page.getByRole('heading', { name: 'Available at Factory' });
  }

  get headingPrice() {
    return this.page.getByRole('heading', { name: 'Price' });
  }

  get headingWeightBand() {
    return this.page.getByRole('heading', { name: 'Weight Band' });
  }

  get headingJewelleryType() {
    return this.page.getByRole('heading', { name: 'Jewellery Type' });
  }

  get headingProduct() {
    return this.page.getByRole('heading', { name: 'Product' });
  }

  get headingGender() {
    return this.page.getByRole('heading', { name: 'Gender' });
  }

  get headingCollection() {
    return this.page.getByRole('heading', { name: 'Collection' });
  }

  get headingMetalColor() {
    return this.page.getByRole('heading', { name: 'Metal Color' });
  }

  get headingType() {
    return this.page.getByRole('heading', { name: 'Type', exact: true });
  }

  get headingCommunity() {
    return this.page.getByRole('heading', { name: 'Community' });
  }

  get headingTrousseau() {
    return this.page.getByRole('heading', { name: 'Trousseau' });
  }

  get headingGoldKaratage() {
    return this.page.getByRole('heading', { name: 'Gold Karatage' });
  }

  get headingOccasion() {
    return this.page.getByRole('heading', { name: 'Occasion' });
  }

  get headingDiamondClarity() {
    return this.page.getByRole('heading', { name: 'Diamond Clarity' });
  }

  get headingPendantHeight() {
    return this.page.getByRole('heading', { name: 'Pendant Height' });
  }

  get headingPendantWidth() {
    return this.page.getByRole('heading', { name: 'Pendant Width' });
  }

  get textEarringWidthClear() {
    return this.page.getByText('Earring WidthClear');
  }

  get headingSize() {
    return this.page.getByRole('heading', { name: 'Size' });
  }

  // ── Grid / Table ─────────────────────────────────────────────────────────────
  get searchResultsRegion() {
    return this.page.getByRole('region', { name: 'Search Results' });
  }

  get firstProductTile() {
    return this.searchResultsRegion.locator('a[href*="product-detail"]').first();
  }

  // ── Product Detail ────────────────────────────────────────────────────────────
  get productDetailContent() {
    return this.page.locator('body');
  }

  get loadingSpinner() {
    return this.page.getByTestId('loading-spinner');
  }

  // ── Notifications & Toasts ────────────────────────────────────────────────────
  get errorBanner() {
    return this.page.getByRole('alert');
  }

  async navigate(): Promise<void> {
    const allProductsCard = this.page.getByRole('link', { name: 'Card Image All Products' });
    if ((await allProductsCard.count()) > 0 && (await allProductsCard.isVisible())) {
      await allProductsCard.click();
    } else {
      await this.page.getByRole('menuitem', { name: 'All Products' }).click();
    }
    await expect.soft(this.page.getByRole('link', { name: 'Earrings' })).toBeVisible({ timeout: 20_000 });
    await this.page.getByRole('link', { name: 'Earrings' }).click();
    await expect.soft(this.page.getByRole('textbox', { name: 'Enter keyword or scan' })).toBeVisible({
      timeout: 30_000,
    });
    await this.page.waitForLoadState('domcontentloaded');
  }

  async clickAllProducts(): Promise<void> {
    await this.linkAllProducts.click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async clickEarringsCategory(): Promise<void> {
    await this.linkEarringsCategory.click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async fillUsername(value: string): Promise<void> {
    await this.inputUsername.fill(value);
  }

  async fillPassword(value: string): Promise<void> {
    await this.inputPassword.fill(value);
  }

  async clickLogin(): Promise<void> {
    await this.btnLogin.click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async clickSearchKeyword(): Promise<void> {
    await this.inputSearchKeyword.click();
  }

  async fillSearchKeyword(value: string): Promise<void> {
    await this.inputSearchKeyword.fill(value);
  }

  async clickSearch(): Promise<void> {
    await this.btnSearch.click();
    await this.searchResultsRegion.locator('a[href*="product-detail"]').first().waitFor({
      state: 'visible',
      timeout: 30_000,
    });
  }

  async clickSortLowToHigh(): Promise<void> {
    await this.btnSortLowToHigh.click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async clickFilterHeading(name: string): Promise<void> {
    await this.page.getByRole('heading', { name, exact: name === 'Type' }).click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async clickEarringWidthClear(): Promise<void> {
    await this.textEarringWidthClear.click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async expandAllFilterSections(): Promise<void> {
    const headings = [
      'Brand',
      'Available at Factory',
      'Price',
      'Weight Band',
      'Jewellery Type',
      'Product',
      'Gender',
      'Collection',
      'Metal Color',
      'Type',
      'Community',
      'Trousseau',
      'Gold Karatage',
      'Occasion',
      'Diamond Clarity',
      'Pendant Height',
      'Pendant Width',
      'Size',
    ];
    for (const heading of headings) {
      await this.clickFilterHeading(heading);
    }
  }

  async clickFirstProductTile(): Promise<void> {
    const tile = this.firstProductTile;
    await tile.waitFor({ state: 'visible', timeout: 20_000 });
    const href = await tile.getAttribute('href');
    if (href) {
      await this.page.goto(new URL(href, this.page.url()).toString());
      await this.page.waitForURL(/product-detail/, { timeout: 30_000 });
      return;
    }
    await tile.click();
    await this.page.waitForURL(/product-detail/, { timeout: 30_000 });
  }

  async selectBrandFilter(brandName: string): Promise<void> {
    await this.headingBrand.click();
    await this.page.getByText(brandName, { exact: false }).first().click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async selectGoldKaratage(value: string): Promise<void> {
    await this.headingGoldKaratage.click();
    await this.page.getByText(value, { exact: false }).first().click();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async doubleClickFilterHeading(name: string): Promise<void> {
    await this.page
      .getByRole('heading', { name, exact: name === 'Type' })
      .dblclick();
    await this.loadingSpinner.waitFor({ state: 'hidden', timeout: 10_000 }).catch(() => {});
  }

  async openInvalidProductDetail(invalidQueryId: string): Promise<void> {
    const baseUrl = this.page.url().includes('/ords/')
      ? this.page.url().split('/ords/')[0]
      : 'https://ai-test.titanrts.com';
    await this.page.goto(
      `${baseUrl}/ords/r/tjdcom/ea/product-detail?p5_query_id=${invalidQueryId}`
    );
    await this.page.waitForLoadState('domcontentloaded');
  }

  async openProductDetailUrl(url: string): Promise<void> {
    await this.page.goto(url);
    await this.page.waitForLoadState('domcontentloaded');
  }

  async reloadPage(): Promise<void> {
    await this.page.reload();
    await this.page.waitForLoadState('domcontentloaded');
  }

  async goBack(): Promise<void> {
    await this.page.goBack();
    await this.page.waitForLoadState('domcontentloaded');
  }

  async getCurrentUrl(): Promise<string> {
    return this.page.url();
  }

  getProductCount(): Promise<number> {
    return this.searchResultsRegion.locator('a[href*="product-detail"]').count();
  }
}

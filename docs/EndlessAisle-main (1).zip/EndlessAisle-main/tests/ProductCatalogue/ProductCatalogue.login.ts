import { test as baseTest, expect } from '@playwright/test';
import type { Page } from '@playwright/test';
import { ProductCataloguePage } from './ProductCatalogue.page';

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(
      `\n\n  Missing required environment variable: ${name}\n` +
      `  Set it in .env or export it in the terminal:\n` +
      `    $env:${name}="...value..."   (PowerShell)\n` +
      `    export ${name}="...value..." (bash/zsh)\n`
    );
  }
  return value;
}

export const BASE_URL   = requireEnv('BASE_URL');
export const LOGIN_URL  = requireEnv('LOGIN_URL');
export const LOGIN_USER = requireEnv('LOGIN_USER');
export const LOGIN_PASS = requireEnv('LOGIN_PASS');

/** Fresh login for a single test (hard gate — test cannot continue if this fails). */
export async function loginToApp(page: Page): Promise<void> {
  await page.goto(LOGIN_URL);
  await page.waitForLoadState('domcontentloaded');
  await page.getByRole('textbox', { name: 'Username' }).fill(LOGIN_USER);
  await page.getByRole('textbox', { name: 'Password' }).fill(LOGIN_PASS);
  await page.getByRole('button', { name: 'LOGIN ›' }).click();
  await expect(page.getByRole('menuitem', { name: 'All Products' })).toBeVisible({
    timeout: 20_000,
  });
}

export async function navigateToProductCatalogue(page: Page): Promise<void> {
  const allProductsCard = page.getByRole('link', { name: 'Card Image All Products' });
  if ((await allProductsCard.count()) > 0 && (await allProductsCard.isVisible())) {
    await allProductsCard.click();
  } else {
    await page.getByRole('menuitem', { name: 'All Products' }).click();
  }
  await expect.soft(page.getByRole('link', { name: 'Earrings' })).toBeVisible({ timeout: 20_000 });
  await page.getByRole('link', { name: 'Earrings' }).click();
  await expect.soft(page.getByRole('textbox', { name: 'Enter keyword or scan' })).toBeVisible({
    timeout: 30_000,
  });
}

/**
 * One isolated session per test: new browser context → Chrome → login → Earrings → work → close.
 * Playwright creates a new context for each test; this runs inside that lifecycle.
 */
export async function openIsolatedCatalogueSession(page: Page): Promise<ProductCataloguePage> {
  await loginToApp(page);
  await navigateToProductCatalogue(page);
  const catalogue = new ProductCataloguePage(page);
  await catalogue.assertEarringsListingReady();
  return catalogue;
}

export const test = baseTest.extend<{ catalogue: ProductCataloguePage }>({
  catalogue: async ({ page }, use) => {
    const catalogue = await openIsolatedCatalogueSession(page);
    await use(catalogue);
  },
});

export const testWithoutAuth = baseTest;

export { expect };

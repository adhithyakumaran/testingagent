import {
  test,
  testWithoutAuth,
  expect,
  LOGIN_URL,
} from './ProductCatalogue.login';
import { ProductCataloguePage } from './ProductCatalogue.page';
import { ProductCatalogueData } from './ProductCatalogue.data';

const TAG_SMOKE    = '@smoke';
const TAG_POSITIVE = '@positive';
const TAG_NEGATIVE = '@negative';

function isPlaceholder(value: string): boolean {
  return value.startsWith('[') && value.endsWith(']');
}

// Each test: new browser context → Chrome → login → Earrings → steps → context closed.
// Verification uses expect.soft() so later steps still run; failures show in the HTML report.

test.describe('ProductCatalogue — Smoke', { tag: TAG_SMOKE }, () => {
  test('ProductCatalogue-MS-001 — Complete browse journey — login, Earrings category, search, sort, open product detail', async ({
    catalogue,
  }) => {
    await catalogue.clickSearchKeyword();
    await catalogue.clickSearch();
    await expect.soft(catalogue.btnSortLowToHigh).toBeVisible();
    await catalogue.clickFirstProductTile();
    await catalogue.assertProductDetailLoaded();
  });

  test('ProductCatalogue-MS-019 — Regression smoke — login, Earrings browse, open product detail', async ({
    catalogue,
  }) => {
    await catalogue.clickSearch();
    await expect.soft(catalogue.btnSortLowToHigh).toBeVisible();
    await catalogue.clickFirstProductTile();
    await catalogue.assertProductDetailLoaded();
  });
});

test.describe('ProductCatalogue — Positive', { tag: TAG_POSITIVE }, () => {
  test('ProductCatalogue-MS-002 — Browse Earrings category after login and verify listing page elements', async ({
    catalogue,
  }) => {
    await expect.soft(catalogue.inputSearchKeyword).toBeEnabled();
    await expect.soft(catalogue.pageTitle).toBeVisible();
    const count = await catalogue.getProductCount();
    expect.soft(count).toBeGreaterThan(0);
    await expect.soft(catalogue.inputSearchKeyword).toBeVisible();
  });

  test('ProductCatalogue-MS-005 — Empty keyword search on Earrings listing executes without error', async ({
    catalogue,
  }) => {
    await catalogue.clickSearchKeyword();
    await catalogue.clickSearch();
    await expect.soft(catalogue.inputSearchKeyword).toBeVisible();
    const count = await catalogue.getProductCount();
    await expect.soft(catalogue.inputSearchKeyword).toBeEnabled();
    expect.soft(count).toBeGreaterThanOrEqual(0);
  });

  test('ProductCatalogue-MS-006 — Toggle price sort using Low to High control twice', async ({
    catalogue,
  }) => {
    await catalogue.clickSearch();
    await catalogue.clickSortLowToHigh();
    await catalogue.clickSortLowToHigh();
    const count = await catalogue.getProductCount();
    await expect.soft(catalogue.btnSortLowToHigh).toBeVisible();
    expect.soft(count).toBeGreaterThan(0);
  });

  test('ProductCatalogue-MS-007 — Expand and collapse all filter accordion sections on Earrings listing', async ({
    catalogue,
  }) => {
    await catalogue.expandAllFilterSections();
    await catalogue.clickEarringWidthClear();
    await catalogue.clickEarringWidthClear();
    const count = await catalogue.getProductCount();
    await expect.soft(catalogue.inputSearchKeyword).toBeVisible();
    expect.soft(count).toBeGreaterThanOrEqual(0);
  });

  test('ProductCatalogue-MS-008 — Search Earrings by valid keyword and verify matching results', async ({
    catalogue,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-008'];
    test.skip(isPlaceholder(data.searchKeyword), 'Replace [VALID_EARRING_KEYWORD] with real data');

    await catalogue.fillSearchKeyword(data.searchKeyword);
    await catalogue.clickSearch();
    const count = await catalogue.getProductCount();
    expect.soft(count).toBeGreaterThan(0);
  });

  test('ProductCatalogue-MS-011 — Open product detail from Earrings grid and verify detail page loads', async ({
    catalogue,
  }) => {
    await catalogue.clickFirstProductTile();
    await expect.soft(catalogue.page).toHaveURL(/product-detail/, { timeout: 30_000 });
    await expect.soft(catalogue.page).toHaveURL(/p5_sku=|p5_query_id=/);
    await expect.soft(catalogue.productDetailContent).toBeVisible();
  });

  test('ProductCatalogue-MS-012 — Product detail query ID persists after page reload', async ({
    catalogue,
  }) => {
    await catalogue.clickFirstProductTile();
    const urlBefore = await catalogue.getCurrentUrl();
    expect.soft(urlBefore).toMatch(/product-detail/);
    await catalogue.reloadPage();
    const urlAfter = await catalogue.getCurrentUrl();
    expect.soft(urlAfter).toMatch(/product-detail/);
  });

  test('ProductCatalogue-MS-013 — End-to-end navigation path from home card through category to product detail', async ({
    catalogue,
  }) => {
    await expect.soft(catalogue.inputSearchKeyword).toBeVisible();
    await catalogue.clickFirstProductTile();
    await expect.soft(catalogue.page).toHaveURL(/product-detail/, { timeout: 30_000 });
    await catalogue.goBack();
    await expect.soft(catalogue.inputSearchKeyword).toBeVisible({ timeout: 15_000 });
    const count = await catalogue.getProductCount();
    expect.soft(count).toBeGreaterThan(0);
  });

  test('ProductCatalogue-MS-014 — Apply Brand filter on Earrings listing and verify grid updates', async ({
    catalogue,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-014'];
    test.skip(isPlaceholder(data.brandName), 'Replace [VALID_BRAND_NAME] with real data');

    await catalogue.selectBrandFilter(data.brandName);
    const count = await catalogue.getProductCount();
    expect.soft(count).toBeGreaterThanOrEqual(0);
  });

  test('ProductCatalogue-MS-015 — Price filter range validation on Earrings listing', async ({
    catalogue,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-015'];
    test.skip(
      isPlaceholder(data.minPrice) || isPlaceholder(data.maxPrice),
      'Replace price placeholders with real data'
    );

    await catalogue.clickFilterHeading('Price');
    await expect.soft(catalogue.headingPrice).toBeVisible();
  });

  test('ProductCatalogue-MS-018 — Rapid repeated clicks on filter headings do not freeze UI', async ({
    catalogue,
  }) => {
    await catalogue.doubleClickFilterHeading('Brand');
    await catalogue.doubleClickFilterHeading('Brand');
    await catalogue.doubleClickFilterHeading('Price');
    await catalogue.doubleClickFilterHeading('Price');
    await expect.soft(catalogue.inputSearchKeyword).toBeEnabled();
    await expect.soft(catalogue.inputSearchKeyword).toBeVisible();
  });

  test('ProductCatalogue-MS-020 — Select Gold Karatage filter section and verify filter panel behaviour', async ({
    catalogue,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-020'];
    test.skip(isPlaceholder(data.karatageValue), 'Replace [VALID_GOLD_KARATAGE] with real data');

    await catalogue.selectGoldKaratage(data.karatageValue);
    const count = await catalogue.getProductCount();
    expect.soft(count).toBeGreaterThanOrEqual(0);
  });
});

test.describe('ProductCatalogue — Negative (authenticated)', { tag: TAG_NEGATIVE }, () => {
  test('ProductCatalogue-MS-009 — Search with non-existent keyword returns no matching products', async ({
    catalogue,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-009'];

    const beforeCount = await catalogue.getProductCount();
    await catalogue.fillSearchKeyword(data.searchKeyword);
    await catalogue.clickSearch();
    const afterCount = await catalogue.getProductCount();
    expect.soft(afterCount).toBeLessThanOrEqual(beforeCount);
  });

  test('ProductCatalogue-MS-010 — Search with special characters does not break listing page', async ({
    catalogue,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-010'];

    await catalogue.fillSearchKeyword(data.searchKeyword);
    await catalogue.clickSearch();
    await expect.soft(catalogue.inputSearchKeyword).toBeVisible();
    await expect.soft(catalogue.inputSearchKeyword).toHaveValue(data.searchKeyword);
  });

  test('ProductCatalogue-MS-017 — Invalid p5_query_id on product detail shows controlled error', async ({
    catalogue,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-017'];

    await catalogue.openInvalidProductDetail(data.invalidQueryId);
    await expect.soft(catalogue.productDetailContent).toBeVisible();
  });
});

testWithoutAuth.describe('ProductCatalogue — Negative (unauthenticated)', { tag: TAG_NEGATIVE }, () => {
  test('ProductCatalogue-MS-003 — Login rejected with valid username and invalid password', async ({
    page,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-003'];
    const loginPage = new ProductCataloguePage(page);

    await page.goto(LOGIN_URL);
    await page.waitForLoadState('domcontentloaded');
    await loginPage.fillUsername(data.username);
    await loginPage.fillPassword(data.invalidPassword);
    await loginPage.clickLogin();
    await loginPage.assertRemainsOnLogin();
  });

  test('ProductCatalogue-MS-004 — Login blocked when Username and Password are both empty', async ({
    page,
  }) => {
    const loginPage = new ProductCataloguePage(page);

    await page.goto(LOGIN_URL);
    await page.waitForLoadState('domcontentloaded');
    await loginPage.clickLogin();
    await expect.soft(page).toHaveURL(/login/);
    await expect.soft(loginPage.btnLogin).toBeVisible();
  });

  test('ProductCatalogue-MS-016 — Unauthenticated direct access to product-detail URL redirects to login', async ({
    page,
  }) => {
    const data = ProductCatalogueData['ProductCatalogue-MS-016'];
    const loginPage = new ProductCataloguePage(page);

    await loginPage.openProductDetailUrl(data.productDetailUrl);
    const url = page.url();
    expect.soft(/login/i.test(url) || !url.includes('product-detail')).toBeTruthy();
  });
});

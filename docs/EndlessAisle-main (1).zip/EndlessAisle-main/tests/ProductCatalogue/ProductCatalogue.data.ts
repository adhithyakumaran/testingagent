import { BASE_URL, LOGIN_USER } from './ProductCatalogue.login';

export const ProductCatalogueData = {
  'ProductCatalogue-MS-001': {
    category: 'Earrings',
    sortOption: '💰 Low to High',
    expectedProductDetailPath: 'product-detail',
  },
  'ProductCatalogue-MS-002': {
    category: 'Earrings',
  },
  'ProductCatalogue-MS-003': {
    username: LOGIN_USER,
    invalidPassword: 'WrongPass!99',
  },
  'ProductCatalogue-MS-004': {},
  'ProductCatalogue-MS-005': {
    category: 'Earrings',
  },
  'ProductCatalogue-MS-006': {
    sortOption: '💰 Low to High',
  },
  'ProductCatalogue-MS-007': {
    filterSections:
      'Brand, Available at Factory, Price, Weight Band, Jewellery Type, Product, Gender, Collection, Metal Color, Type, Community, Trousseau, Gold Karatage, Occasion, Diamond Clarity, Pendant Height, Pendant Width, Size',
  },
  'ProductCatalogue-MS-008': {
    searchKeyword: '[VALID_EARRING_KEYWORD]',
  },
  'ProductCatalogue-MS-009': {
    searchKeyword: 'ZZZ-NO-MATCH-99999',
  },
  'ProductCatalogue-MS-010': {
    searchKeyword: '%&*<>',
  },
  'ProductCatalogue-MS-011': {
    expectedUrlFragment: 'product-detail',
    sampleQueryId: 'IBTQRYTBO011333344',
    category: 'Earrings',
  },
  'ProductCatalogue-MS-012': {
    sampleQueryId: 'IBTQRYTBO011333344',
  },
  'ProductCatalogue-MS-013': {
    category: 'Earrings',
  },
  'ProductCatalogue-MS-014': {
    brandName: '[VALID_BRAND_NAME]',
  },
  'ProductCatalogue-MS-015': {
    minPrice: '[MIN_PRICE_GBP]',
    maxPrice: '[MAX_PRICE_GBP]',
    invalidMinPrice: '-1',
    invalidMaxPrice: 'abc',
  },
  'ProductCatalogue-MS-016': {
    productDetailUrl: `${BASE_URL}product-detail?p5_query_id=IBTQRYTBO011333344`,
  },
  'ProductCatalogue-MS-017': {
    invalidQueryId: 'INVALID-QUERY-000',
  },
  'ProductCatalogue-MS-018': {},
  'ProductCatalogue-MS-019': {
    category: 'Earrings',
    sortOption: '💰 Low to High',
  },
  'ProductCatalogue-MS-020': {
    karatageValue: '[VALID_GOLD_KARATAGE]',
  },
};

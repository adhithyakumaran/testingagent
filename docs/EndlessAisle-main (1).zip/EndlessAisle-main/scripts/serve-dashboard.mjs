import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const reportsRoot = path.join(__dirname, '..', 'reports');
const port = Number(process.env.DASHBOARD_PORT || 9401);

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.json': 'application/json',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webm': 'video/webm',
  '.zip': 'application/zip',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
};

/** Map URL paths to files under reports/ (fixes /reports/history/... double-prefix 404s). */
function resolveReportsFile(urlPath) {
  if (urlPath === '/' || urlPath === '') {
    return path.join(reportsRoot, 'dashboard', 'index.html');
  }
  if (urlPath.startsWith('/reports/')) {
    return path.join(reportsRoot, urlPath.slice('/reports/'.length));
  }
  if (urlPath.startsWith('/dashboard')) {
    return path.join(reportsRoot, urlPath.slice(1));
  }
  return path.join(reportsRoot, urlPath.replace(/^\//, ''));
}

const server = http.createServer((req, res) => {
  let urlPath = decodeURIComponent(req.url?.split('?')[0] || '/');
  const filePath = path.resolve(resolveReportsFile(urlPath));
  const rootResolved = path.resolve(reportsRoot);

  if (!filePath.startsWith(rootResolved)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  let target = filePath;
  if (fs.existsSync(target) && fs.statSync(target).isDirectory()) {
    target = path.join(target, 'index.html');
  }

  if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
    return;
  }

  const ext = path.extname(target).toLowerCase();
  res.writeHead(200, {
    'Content-Type': mime[ext] || 'application/octet-stream',
    'Cache-Control': 'no-cache',
  });
  fs.createReadStream(target).pipe(res);
});

server.listen(port, () => {
  console.log(`QA dashboard: http://localhost:${port}/dashboard/`);
  console.log(`Playwright reports: http://localhost:${port}/reports/history/<run-id>/html-report/index.html`);
});

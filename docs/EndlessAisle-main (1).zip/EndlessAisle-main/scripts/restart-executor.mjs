/**
 * Free executor port (from config) and start executor/server.js.
 */
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { freePort } from './free-port.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');

function readPort() {
  const configPath = path.join(root, 'executor', 'config.json');
  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  return config.server?.port ?? 9500;
}

const port = readPort();
console.log(`\nFreeing port ${port}...`);
freePort(port);

await new Promise((r) => setTimeout(r, 500));

console.log(`Starting executor on http://localhost:${port} ...\n`);

const child = spawn(process.execPath, ['executor/server.js'], {
  cwd: root,
  stdio: 'inherit',
  env: process.env,
});

child.on('error', (err) => {
  console.error('Failed to start executor:', err.message);
  process.exit(1);
});

child.on('exit', (code) => process.exit(code ?? 0));

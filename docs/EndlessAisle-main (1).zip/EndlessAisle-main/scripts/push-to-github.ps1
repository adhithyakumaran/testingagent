# Push EndlessAisle to GitHub (run from repo root after: gh auth login)
$ErrorActionPreference = 'Stop'
$Root = Split-Path $PSScriptRoot -Parent
$Git  = Join-Path $Root '.tools\PortableGit\cmd\git.exe'
$Gh   = Join-Path $Root '.tools\bin\gh.exe'

if (-not (Test-Path $Git)) { throw "Portable Git not found at $Git. Re-run setup or install Git for Windows." }
if (-not (Test-Path $Gh))  { throw "GitHub CLI not found at $Gh." }

& $Gh auth status 2>$null
if ($LASTEXITCODE -ne 0) {
  Write-Host "Not logged into GitHub. Starting login (browser)..." -ForegroundColor Yellow
  & $Gh auth login --hostname github.com --git-protocol https --web
}

$RepoName = if ($env:GITHUB_REPO_NAME) { $env:GITHUB_REPO_NAME } else { 'EndlessAisle' }
$Visibility = if ($env:GITHUB_REPO_PRIVATE -eq '0') { '--public' } else { '--private' }

Write-Host "Creating/updating remote and pushing to GitHub repo: $RepoName ($Visibility)..." -ForegroundColor Cyan
Set-Location $Root

$remoteUrl = & $Gh repo view $RepoName --json url -q .url 2>$null
if (-not $remoteUrl) {
  & $Gh repo create $RepoName $Visibility --source=. --remote=origin --push
} else {
  & $Git remote remove origin 2>$null
  & $Git remote add origin "https://github.com/$( & $Gh api user -q .login )/$RepoName.git"
  & $Git push -u origin main
}

Write-Host "Done. Remote:" -ForegroundColor Green
& $Git remote -v

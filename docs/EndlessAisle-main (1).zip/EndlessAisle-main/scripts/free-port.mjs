/**
 * Free a TCP port by stopping listening processes (Windows: netstat + taskkill).
 * Port is read from executor/config.json unless --port is passed.
 */
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');

function readPort() {
  const arg = process.argv.find((a) => a.startsWith('--port='));
  if (arg) return Number(arg.split('=')[1]);
  const configPath = path.join(root, 'executor', 'config.json');
  const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  return config.server?.port ?? 9500;
}

function freePortWindows(port) {
  let out = '';
  try {
    out = execSync(`netstat -ano | findstr :${port}`, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] });
  } catch {
    return 0;
  }

  const pids = new Set();
  for (const line of out.split(/\r?\n/)) {
    if (!/LISTENING/i.test(line)) continue;
    const parts = line.trim().split(/\s+/);
    const pid = Number.parseInt(parts[parts.length - 1], 10);
    if (Number.isFinite(pid) && pid > 0) pids.add(pid);
  }

  let killed = 0;
  for (const pid of pids) {
    try {
      execSync(`taskkill /F /PID ${pid}`, { stdio: 'ignore' });
      console.log(`Stopped process ${pid} (was listening on port ${port})`);
      killed += 1;
    } catch {
      console.warn(`Could not stop PID ${pid}`);
    }
  }
  return killed;
}

function freePortUnix(port) {
  try {
    execSync(`lsof -ti tcp:${port} | xargs kill -9 2>/dev/null`, {
      shell: true,
      stdio: 'ignore',
    });
    return 1;
  } catch {
    return 0;
  }
}

const port = readPort();
if (!Number.isFinite(port) || port < 1 || port > 65535) {
  console.error('Invalid port');
  process.exit(1);
}

export function freePort(port) {
  const killed = process.platform === 'win32' ? freePortWindows(port) : freePortUnix(port);
  if (killed === 0) {
    console.log(`Port ${port} is free (no listener found).`);
  }
  return killed;
}

const isMain =
  process.argv[1] &&
  path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url));

if (isMain) {
  freePort(readPort());
}

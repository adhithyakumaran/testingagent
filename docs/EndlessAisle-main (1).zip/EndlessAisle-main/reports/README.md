# Reports layout

| Path | Purpose |
|------|---------|
| `html-report/` | Latest Playwright HTML report (overwritten each run) |
| `test-results/` | Latest run artifacts (screenshots, video, trace) |
| `history/<run-id>/` | **Permanent archive** — full copy of report + artifacts + `run-meta.json` |
| `history/index.json` | Manifest of all runs (never trimmed automatically) |
| `dashboard/index.html` | QA intelligence dashboard (trends, failures, links) |

Archiving runs automatically via `reporters/history-reporter.ts` after every test execution.

## Office dashboard (Test Executor)

For associates and management to run suites and browse history in a browser:

```powershell
npm run executor
```

Open **http://localhost:9500** (LAN: **http://\<pc-ip\>:9500**). See `executor/README.md` for Run Detail, filters, and firewall notes.

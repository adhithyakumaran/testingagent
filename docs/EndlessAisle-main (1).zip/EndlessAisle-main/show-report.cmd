@echo off
set "NODE_DIR=%LOCALAPPDATA%\Programs\nodejs"
if not exist "%NODE_DIR%\node.exe" (
  echo Node.js not found at %NODE_DIR%
  echo Install Node from https://nodejs.org/ or add node to PATH.
  exit /b 1
)
set "PATH=%NODE_DIR%;%PATH%"
cd /d "%~dp0"
"%NODE_DIR%\node.exe" .\node_modules\playwright\cli.js show-report reports\html-report --port 9400

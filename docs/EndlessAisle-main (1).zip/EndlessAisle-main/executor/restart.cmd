@echo off
title Endless Aisle — Restart Test Executor
cd /d "%~dp0.."
echo.
echo  Restarting executor (free port 9500, then start)...
echo.
node scripts\restart-executor.mjs
pause

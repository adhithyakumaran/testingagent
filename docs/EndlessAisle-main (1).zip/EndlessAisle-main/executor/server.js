'use strict';
// ─────────────────────────────────────────────────────────────────────────────
// Endless Aisle — Test Executor Server
// Pure Node.js — zero npm dependencies.
// Serves the web UI, triggers Playwright test runs, streams live events via
// Server-Sent Events (SSE), and serves all report files (Playwright HTML
// report, archived history, intelligence dashboard).
// ─────────────────────────────────────────────────────────────────────────────
const http   = require('http');
const fs     = require('fs');
const path   = require('path');
const { spawn, execFileSync } = require('child_process');
const { loadRunDetail, getLatestHistoryRunId } = require('./lib/history-detail');
const {
  loadRegistry,
  getProject,
  resolveProjectId,
  listProjects,
  getProjectSuites,
  findSuiteById,
  listSuiteTests,
  reportBase,
} = require('./lib/projects');

// ── Load config & projects ────────────────────────────────────────────────────

function findNodeExe(project) {
  const nodeDirSetting = project?.nodeDir || 'auto';
  if (nodeDirSetting && nodeDirSetting !== 'auto') {
    const e = path.join(nodeDirSetting, 'node.exe');
    if (fs.existsSync(e)) return e;
  }
  const win = path.join(process.env.LOCALAPPDATA || '', 'Programs', 'nodejs', 'node.exe');
  if (fs.existsSync(win)) return win;
  return process.execPath;
}

const REGISTRY = loadRegistry(findNodeExe);
const PORT = REGISTRY.server.port || 9500;
const HOST = REGISTRY.server.host || 'localhost';
const PUBLIC_DIR = path.join(__dirname, 'public');

function resolveProjectFromRequest(url, bodyProject) {
  return getProject(REGISTRY, url.searchParams.get('project') || bodyProject || null);
}

// Warm up default project suite discovery at startup
getProjectSuites(getProject(REGISTRY, REGISTRY.defaultProject));

// ── MIME ──────────────────────────────────────────────────────────────────────

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'text/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.webp': 'image/webp',
  '.webm': 'video/webm',
  '.zip':  'application/zip',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
  '.woff2':'font/woff2',
  '.md':   'text/markdown; charset=utf-8',
};
const mime = (f) => MIME[path.extname(f).toLowerCase()] || 'application/octet-stream';

// ── File server ───────────────────────────────────────────────────────────────

function serveFile(filePath, res) {
  if (!fs.existsSync(filePath)) {
    res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found'); return;
  }
  const stat = fs.statSync(filePath);
  if (stat.isDirectory()) {
    const idx = path.join(filePath, 'index.html');
    if (fs.existsSync(idx)) return serveFile(idx, res);
    res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Directory listing disabled'); return;
  }
  res.writeHead(200, { 'Content-Type': mime(filePath), 'Content-Length': stat.size, 'Cache-Control': 'no-cache' });
  fs.createReadStream(filePath).pipe(res);
}

function guardedServe(filePath, rootDir, res) {
  const resolved = path.resolve(filePath);
  if (!resolved.startsWith(path.resolve(rootDir))) {
    res.writeHead(403, { 'Content-Type': 'text/plain' }); res.end('Forbidden'); return;
  }
  serveFile(resolved, res);
}

// ── Active run state ──────────────────────────────────────────────────────────

let currentRun = null;

function makeRun(suite, opts = {}) {
  return {
    id:        `run_${Date.now()}`,
    suite,
    opts,
    status:    'running',
    killed:    false,
    startedAt: Date.now(),
    events:    [],
    clients:   new Set(),
    child:     null,
    total:     opts.testLocation ? 1 : (suite.estimatedTests || 0),
    completed: 0,
    passed:    0,
    failed:    0,
    skipped:   0,
  };
}

function broadcast(run, event) {
  run.events.push(event);
  const data = `data: ${JSON.stringify(event)}\n\n`;
  for (const res of run.clients) { try { res.write(data); } catch (_) {} }
}

// ── Playwright output parser ───────────────────────────────────────────────────
// Playwright list reporter emits:
//   ✓  1 [chromium] › file:line › Suite › Test Title  (Xs)   ← passed (U+2713)
//   ×  2 [chromium] › file:line › Suite › Test Title  (Xs)   ← failed (U+00D7)
//   -  3 Test Title                                           ← skipped
//   Running N tests using M workers
//   N passed (Xs) / N failed / N skipped

function extractTitle(line) {
  const segs = line.split('›');
  const raw  = segs.length >= 2 ? segs[segs.length - 1] : line;
  return raw.replace(/\s*\(\d[\d.]*s\)\s*$/, '').trim();
}

const RE_TOTAL = /Running (\d+) tests?/;
const RE_PASS  = /^\s*[✓✔]\s+\d+/u;
const RE_FAIL  = /^\s*[✗×✘]\s+\d+/u;
const RE_SKIP  = /^\s*-\s+\d+/u;
const RE_DUR   = /\([\d.]+s\)\s*$/;

function parseLine(line, run) {
  let m;

  if ((m = RE_TOTAL.exec(line))) {
    run.total = parseInt(m[1], 10);
    broadcast(run, { type: 'total', total: run.total });
    return;
  }

  if (RE_PASS.test(line)) {
    run.passed++; run.completed++;
    const dur = (RE_DUR.exec(line) || [''])[0].replace(/[()]/g,'').trim();
    broadcast(run, { type: 'test', status: 'passed', title: extractTitle(line), index: run.completed, total: run.total, duration: dur });
    return;
  }

  if (RE_FAIL.test(line)) {
    run.failed++; run.completed++;
    const dur = (RE_DUR.exec(line) || [''])[0].replace(/[()]/g,'').trim();
    broadcast(run, { type: 'test', status: 'failed', title: extractTitle(line), index: run.completed, total: run.total, duration: dur });
    return;
  }

  if (RE_SKIP.test(line)) {
    run.skipped++; run.completed++;
    broadcast(run, { type: 'test', status: 'skipped', title: extractTitle(line), index: run.completed, total: run.total, duration: '' });
    return;
  }

  // Summary line or raw output
  const trimmed = line.trim();
  if (trimmed) broadcast(run, { type: 'stdout', line: trimmed });
}

// ── Start a test run ──────────────────────────────────────────────────────────

function startRun(project, suiteConfig, opts = {}) {
  if (currentRun && currentRun.status === 'running') {
    return { error: 'A run is already in progress. Wait for it to finish.' };
  }

  const defaults  = project.executionDefaults || {};
  const browsers  = project.browsers || [{ id:'chromium', project:'chromium' }];
  const headed  = opts.headed ?? defaults.headed ?? false;
  const workers = Math.max(1, Math.min(opts.workers ?? defaults.workers ?? 1, defaults.maxWorkers ?? 8));
  const retries = Math.max(0, Math.min(opts.retries ?? defaults.retries ?? 0, defaults.maxRetries ?? 5));
  const browserId = opts.browser ?? defaults.browser ?? 'chromium';
  const browser   = browsers.find(b => b.id === browserId) || browsers[0];

  const run = makeRun(suiteConfig, {
    headed,
    workers,
    retries,
    browser: browser.id,
    browserLabel: browser.label,
    testLocation: opts.testLocation,
    projectId: project.id,
    projectName: project.name,
  });
  currentRun = run;

  const nodeExe = findNodeExe(project);
  const nodeDir = path.dirname(nodeExe);
  const cli     = path.join(project.suiteRoot, 'node_modules', 'playwright', 'cli.js');

  const args = [cli, 'test'];
  if (opts.testLocation) {
    args.push(String(opts.testLocation).replace(/\\/g, '/'));
  } else {
    args.push(suiteConfig.path || 'tests/ProductCatalogue');
    if (suiteConfig.tag) args.push('--grep', suiteConfig.tag);
  }
  args.push('--project', browser.project);
  args.push('--workers', String(workers));
  args.push('--retries', String(retries));
  if (headed) args.push('--headed');

  const env = {
    ...process.env,
    RUN_SUITE:             suiteConfig.id,
    RUN_TAG:               suiteConfig.tag || '',
    HEADLESS:    headed ? 'false' : 'true',
    PW_WORKERS:  String(workers),
    FORCE_COLOR:           '0',
    PATH: `${nodeDir}${path.delimiter}${process.env.PATH || ''}`,
  };

  const singleTest = Boolean(opts.testLocation);
  broadcast(run, {
    type:        'start',
    suite:       suiteConfig.id,
    suiteLabel:  singleTest
      ? `${suiteConfig.fullLabel} — ${opts.testTitle || opts.testLocation}`
      : suiteConfig.fullLabel,
    total:       singleTest ? 1 : suiteConfig.estimatedTests,
    headed,
    workers,
    retries,
    browser:     browser.id,
    browserLabel:browser.label,
    testTitle:   opts.testTitle || null,
    startedAt:   new Date().toISOString(),
  });

  const child = spawn(nodeExe, args, { cwd: project.suiteRoot, env });
  run.child = child;

  let buf = '';
  const flush = (final = false) => {
    const lines = buf.split('\n');
    buf = final ? '' : (lines.pop() || '');
    for (const l of lines) parseLine(l, run);
  };

  child.stdout.on('data', (c) => { buf += c.toString(); flush(); });
  child.stderr.on('data', (c) => { buf += c.toString(); flush(); });

  child.on('close', (code) => {
    flush(true);
    const durationMs = Date.now() - run.startedAt;
    if (run.killed) {
      run.status = 'killed';
      broadcast(run, {
        type:      'killed',
        passed:    run.passed,
        failed:    run.failed,
        skipped:   run.skipped,
        total:     run.total,
        durationMs,
      });
    } else {
      run.status = code === 0 ? 'passed' : 'failed';
      const historyRunId = getLatestHistoryRunId(project.historyIndex);
      broadcast(run, {
        type:         'done',
        status:       run.status,
        passed:       run.passed,
        failed:       run.failed,
        skipped:      run.skipped,
        total:        run.total,
        durationMs,
        opts:         run.opts,
        projectId:    project.id,
        reportUrl:    `${reportBase(project.id)}/playwright/`,
        dashboardUrl: `${reportBase(project.id)}/dashboard/`,
        historyRunId: historyRunId || null,
      });
    }
    for (const res of run.clients) { try { res.end(); } catch (_) {} }
    run.clients.clear();
  });

  child.on('error', (err) => {
    run.status = 'error';
    broadcast(run, { type: 'error', message: err.message });
  });

  return { runId: run.id };
}

// ── HTTP request handler ──────────────────────────────────────────────────────

const server = http.createServer((req, res) => {
  const url      = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  // Universal CORS + no-cache for API
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // ── /api/projects ─────────────────────────────────────────────────────────
  if (pathname === '/api/projects' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      defaultProject: REGISTRY.defaultProject,
      projects: listProjects(REGISTRY),
    }));
    return;
  }

  // ── /api/config ───────────────────────────────────────────────────────────
  if (pathname === '/api/config' && req.method === 'GET') {
    const project = resolveProjectFromRequest(url);
    const suites = getProjectSuites(project);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      projectId: project.id,
      projectName: project.name,
      projects: listProjects(REGISTRY),
      defaultProject: REGISTRY.defaultProject,
      env: project.env || REGISTRY.env,
      suites,
      browsers: project.browsers || [],
      port: PORT,
      executionDefaults: project.executionDefaults || {},
      reportBase: reportBase(project.id),
    }));
    return;
  }

  // ── /api/status ───────────────────────────────────────────────────────────
  if (pathname === '/api/status' && req.method === 'GET') {
    const requestedProject = url.searchParams.get('project');
    const running = !!(currentRun && currentRun.status === 'running');
    const payload = {
      busy: running,
      projectId: currentRun?.opts?.projectId || resolveProjectId(REGISTRY, requestedProject),
      lastRun: currentRun ? {
        id:      currentRun.id,
        suite:   currentRun.suite.id,
        status:  currentRun.status,
        passed:  currentRun.passed,
        failed:  currentRun.failed,
        skipped: currentRun.skipped,
        total:   currentRun.total,
        projectId: currentRun.opts?.projectId || null,
      } : null,
      currentRun: null,
    };
    if (running && currentRun) {
      const completed = currentRun.passed + currentRun.failed + currentRun.skipped;
      payload.currentRun = {
        id:          currentRun.id,
        suiteId:     currentRun.suite.id,
        suiteLabel:  currentRun.suite.fullLabel || currentRun.suite.label,
        projectId:   currentRun.opts?.projectId || null,
        projectName: currentRun.opts?.projectName || null,
        startedAt:   currentRun.startedAt,
        passed:      currentRun.passed,
        failed:      currentRun.failed,
        skipped:     currentRun.skipped,
        total:       currentRun.total,
        completed,
        durationMs:  Date.now() - currentRun.startedAt,
      };
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(payload));
    return;
  }

  // ── /api/suites/:id/tests  (GET — list tests in suite) ────────────────────
  const suiteTestsMatch = pathname.match(/^\/api\/suites\/([^/]+)\/tests$/);
  if (suiteTestsMatch && req.method === 'GET') {
    const project = resolveProjectFromRequest(url);
    const suiteId = decodeURIComponent(suiteTestsMatch[1]);
    const suiteConfig = findSuiteById(project, suiteId);
    if (!suiteConfig) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: `Unknown suite: ${suiteId}` }));
      return;
    }
    const refresh = url.searchParams.get('refresh') === '1';
    try {
      const tests = listSuiteTests(project, suiteConfig, refresh);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        suiteId: suiteConfig.id,
        suiteLabel: suiteConfig.fullLabel,
        count: tests.length,
        tests,
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: String(err.message) }));
    }
    return;
  }

  // ── /api/run  (POST — start a run) ────────────────────────────────────────
  if (pathname === '/api/run' && req.method === 'POST') {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      try {
        const {
          suite: suiteId,
          headed,
          workers,
          retries,
          browser,
          testLocation,
          testTitle,
          project: bodyProject,
        } = JSON.parse(body || '{}');
        const project = resolveProjectFromRequest(url, bodyProject);
        const suiteConfig = findSuiteById(project, suiteId);
        if (!suiteConfig) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: `Unknown suite: ${suiteId}` })); return;
        }
        const result = startRun(project, suiteConfig, { headed, workers, retries, browser, testLocation, testTitle });
        res.writeHead(result.error ? 409 : 200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: String(err.message) }));
      }
    });
    return;
  }

  // ── /api/run/:id/events  (GET — SSE stream) ───────────────────────────────
  const evMatch = pathname.match(/^\/api\/run\/([^/]+)\/events$/);
  if (evMatch && req.method === 'GET') {
    const runId = evMatch[1];
    if (!currentRun || currentRun.id !== runId) {
      res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Run not found'); return;
    }
    res.writeHead(200, {
      'Content-Type':      'text/event-stream',
      'Cache-Control':     'no-cache',
      'Connection':        'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    if (res.flushHeaders) res.flushHeaders();

    // Replay all buffered events so late-joiners / page refreshes catch up
    for (const ev of currentRun.events) res.write(`data: ${JSON.stringify(ev)}\n\n`);

    if (currentRun.status !== 'running') { res.end(); return; }

    currentRun.clients.add(res);
    req.on('close', () => { currentRun?.clients.delete(res); });
    return;
  }

  // ── /api/run/:id/kill  (POST — stop a run) ───────────────────────────────
  const killMatch = pathname.match(/^\/api\/run\/([^/]+)\/kill$/);
  if (killMatch && req.method === 'POST') {
    const runId = killMatch[1];
    if (!currentRun || currentRun.id !== runId) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Run not found' })); return;
    }
    if (currentRun.status !== 'running') {
      res.writeHead(409, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Run is not active' })); return;
    }
    currentRun.killed = true;
    try {
      currentRun.child?.kill('SIGTERM');
      // Force-kill after 4 s if still alive (Windows doesn't support SIGTERM)
      setTimeout(() => { try { currentRun?.child?.kill('SIGKILL'); } catch (_) {} }, 4000);
    } catch (_) {}
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true }));
    return;
  }

  // ── /api/history ──────────────────────────────────────────────────────────
  if (pathname === '/api/history' && req.method === 'GET') {
    const project = resolveProjectFromRequest(url);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(fs.existsSync(project.historyIndex)
      ? fs.readFileSync(project.historyIndex, 'utf8')
      : JSON.stringify({ version: 1, runs: [] }));
    return;
  }

  // ── /api/history/:runId ───────────────────────────────────────────────────
  const histDetailMatch = pathname.match(/^\/api\/history\/([^/]+)$/);
  if (histDetailMatch && req.method === 'GET') {
    const project = resolveProjectFromRequest(url);
    const runId = decodeURIComponent(histDetailMatch[1]);
    const detail = loadRunDetail(project.historyDir, runId);
    if (!detail) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: `Run not found: ${runId}` }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(detail));
    return;
  }

  // ── Report file serving (/reports/:projectId/playwright|history|dashboard/) ─

  const scopedReportMatch = pathname.match(/^\/reports\/([^/]+)\/(playwright|history|dashboard)(\/.*)?$/);
  if (scopedReportMatch) {
    const projectId = decodeURIComponent(scopedReportMatch[1]);
    const kind = scopedReportMatch[2];
    const rest = scopedReportMatch[3] || '/';
    const project = getProject(REGISTRY, projectId);
    const rel = rest.replace(/^\//, '') || (kind === 'dashboard' ? 'index.html' : 'index.html');

    if (kind === 'playwright') {
      guardedServe(path.join(project.playwrightReport, rel || 'index.html'), project.playwrightReport, res);
      return;
    }
    if (kind === 'history') {
      guardedServe(path.join(project.historyDir, rest.replace(/^\//, '')), project.historyDir, res);
      return;
    }
    if (kind === 'dashboard') {
      guardedServe(path.join(project.dashboardDir, rel || 'index.html'), project.dashboardDir, res);
      return;
    }
  }

  // Legacy report paths — use ?project= query param
  const legacyProject = resolveProjectFromRequest(url);
  const reportPath = pathname;

  if (reportPath.startsWith('/reports/playwright/')) {
    guardedServe(
      path.join(legacyProject.playwrightReport, reportPath.replace('/reports/playwright/', '') || 'index.html'),
      legacyProject.playwrightReport,
      res
    );
    return;
  }

  if (reportPath.startsWith('/reports/history/')) {
    guardedServe(
      path.join(legacyProject.historyDir, reportPath.replace('/reports/history/', '')),
      legacyProject.historyDir,
      res
    );
    return;
  }

  if (reportPath.startsWith('/reports/dashboard/')) {
    guardedServe(
      path.join(legacyProject.dashboardDir, reportPath.replace('/reports/dashboard/', '') || 'index.html'),
      legacyProject.dashboardDir,
      res
    );
    return;
  }

  if (pathname.startsWith('/reports/')) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Report file not found');
    return;
  }

  // ── Static UI files ───────────────────────────────────────────────────────

  if (pathname === '/' || pathname === '/index.html') {
    serveFile(path.join(PUBLIC_DIR, 'index.html'), res); return;
  }

  const staticPath = path.join(PUBLIC_DIR, pathname.slice(1));
  if (staticPath.startsWith(PUBLIC_DIR) && fs.existsSync(staticPath) && !fs.statSync(staticPath).isDirectory()) {
    serveFile(staticPath, res); return;
  }

  // SPA fallback — everything else serves index.html
  serveFile(path.join(PUBLIC_DIR, 'index.html'), res);
});

server.listen(PORT, HOST, () => {
  const lanHint = HOST === '0.0.0.0' || HOST === '::'
    ? `http://localhost:${PORT}  (LAN: http://<this-pc-ip>:${PORT})`
    : `http://${HOST}:${PORT}`;
  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║   Multi-Project Test Executor                   ║');
  console.log('╚══════════════════════════════════════════════════╝');
  console.log(`\n  Open in browser:  ${lanHint}`);
  console.log(`  Environment:      ${String(REGISTRY.env).toUpperCase()}`);
  console.log(`  Projects:`);
  for (const p of listProjects(REGISTRY)) {
    const proj = getProject(REGISTRY, p.id);
    console.log(`    • ${p.name} (${p.id})`);
    console.log(`      root: ${proj.suiteRoot}`);
    console.log(`      reports: ${proj.reportsDir}`);
  }
  console.log('\n  Ctrl+C to stop\n');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n  ERROR: Port ${PORT} is already in use.`);
    console.error(`  Change "server.port" in executor/config.json and restart.\n`);
  } else {
    console.error('\n  Server error:', err.message, '\n');
  }
  process.exit(1);
});

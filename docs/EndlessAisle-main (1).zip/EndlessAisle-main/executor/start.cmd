@echo off
title Endless Aisle — Test Executor

:: ── Find Node.js ──────────────────────────────────────────────────────────────
set "NODE_EXE="
set "LOCAL_NODE=%LOCALAPPDATA%\Programs\nodejs\node.exe"

if exist "%LOCAL_NODE%" (
  set "NODE_EXE=%LOCAL_NODE%"
  set "PATH=%LOCALAPPDATA%\Programs\nodejs;%PATH%"
  goto :run
)

:: Fallback — check if node is already on PATH
where node >nul 2>&1
if %ERRORLEVEL% == 0 (
  set "NODE_EXE=node"
  goto :run
)

echo.
echo  ERROR: Node.js not found.
echo  Install from https://nodejs.org/ (LTS) and re-run this script.
echo.
pause
exit /b 1

:run
cd /d "%~dp0.."
echo.
echo  Freeing port 9500 if in use...
"%NODE_EXE%" scripts\free-port.mjs
echo.
echo  Starting Endless Aisle Test Executor...
echo  Open in browser: http://localhost:9500
echo  Ctrl+C to stop
echo.
"%NODE_EXE%" executor\server.js
pause

# Test Executor Dashboard

Office-friendly web UI to **run Playwright suites**, watch **live progress**, browse **run history**, and open **screenshots, videos, and error reports** from archived runs.

**One executor can serve multiple Playwright projects** — use the project dropdown in the header to switch (Endless Aisle is the first configured project).

## Quick start

From the project root:

```powershell
npm install
npx playwright install
npm run executor:restart
```

Or on Windows (Command Prompt): double-click `executor\restart.cmd`, or run `npm run executor:restart`.

If port 9500 is stuck: `npm run executor:kill-port` then `npm run executor`.

Open in a browser:

| Who | URL |
|-----|-----|
| On the same PC | http://localhost:9500 |
| Colleagues on your office LAN | http://\<your-pc-ip\>:9500 |

Find your IP: `ipconfig` → IPv4 Address (e.g. `192.168.1.42`).

**Windows Firewall:** allow inbound TCP port **9500** for private networks if others cannot connect.

## Tabs

| Tab | Purpose |
|-----|---------|
| **Run Tests** | Pick a suite (tags or folder), browser, headed/headless, workers; live log and progress. Suite badges show live test counts from `playwright test --list` (not spec file count). |
| **Tests** | Browse every test in a suite (titles from Playwright), run one test or the full suite; links from **View tests →** on suite cards. |
| **History** | Filter past runs; open Playwright report or **Run Detail** (per-test artifacts) |
| **Run Detail** | Pass/fail breakdown, errors, screenshots, video, error-context markdown |
| **Dashboard** | KPIs, trends, suite health, failure hotspots, flaky candidates |

**Report** opens the Playwright HTML report in a **new browser tab** (`window.open`). History uses each run’s `reportUrl` under `/reports/<project-id>/history/...`. **View Report** after a run uses `/reports/<project-id>/playwright/` (latest HTML). Static QA dashboard: `npm run dashboard` → http://localhost:9401/dashboard/

## While a run is in progress

- A **banner** appears on every tab: suite name, live counts, elapsed time.
- Only **one run** can execute at a time on this machine; other users see “run in progress” and cannot start another until it finishes or is stopped.
- Use **Stop** on the Run Tests tab to cancel the active run.

## Configuration

Edit `executor/config.json`:

| Setting | Default | Notes |
|---------|---------|--------|
| `defaultProject` | `endless-aisle` | Project loaded when no `?project=` or saved choice |
| `server.port` | `9500` | Change if port is in use |
| `server.host` | `0.0.0.0` | Listens on all interfaces for LAN access; use `localhost` to block remote access |
| `projects[].id` | — | URL-safe slug (used in report paths and API) |
| `projects[].name` | — | Label shown in the project dropdown |
| `projects[].paths.suiteRoot` | `..` | Playwright project root (relative to `executor/`) |
| `projects[].paths.reportsDir` | `../reports` | History archives and dashboard data |
| `projects[].suites` | — | Suite cards and tags for that project |
| `projects[].executionDefaults` | — | Default browser, headed, workers, retries |
| `projects[].browsers` | — | Browser picker options |

### Add another project

Duplicate the object under `projects[]`, give it a unique `id` and `name`, and point `paths.suiteRoot` / `paths.reportsDir` at that repo’s Playwright root and reports folder. Restart the executor (`npm run executor:restart`). The project dropdown appears when more than one project is configured.

Example second entry (paths relative to `executor/`):

```json
{
  "id": "my-other-app",
  "name": "My Other App",
  "paths": {
    "suiteRoot": "../../OtherApp",
    "reportsDir": "../../OtherApp/reports",
    "nodeDir": "auto"
  },
  "suites": [ ... ],
  "executionDefaults": { "browser": "chromium", "headed": true, "workers": 1, "maxWorkers": 4 },
  "browsers": [ ... ]
}
```

The selected project is remembered in the browser (`localStorage` key `ea-executor-project`).

## Reports and archives

Runs triggered from the dashboard still use the project’s Playwright setup. After each run, artifacts are stored under `reports/history/<run-id>/` (when the project’s history reporter has run at least once from CLI or a prior archived run).

- **Latest HTML report:** `/reports/<project-id>/playwright/` (from the executor)
- **Archived run:** `/reports/<project-id>/history/<run-id>/html-report/`
- **Per-test artifacts:** `reports/history/<run-id>/test-results/` under each project’s `reportsDir` (screenshots, `video.webm`, `error-context.md`, traces)

Legacy paths `/reports/playwright/` still work for the default project via `?project=`.

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Port in use | `npm run executor:restart` or `npm run executor:kill-port` (Windows: `executor\restart.cmd`) |
| LAN cannot connect | Set `host` to `0.0.0.0`, check firewall, confirm same network |
| Empty history | Run a suite once via CLI (`npm run test:smoke`) or from **Run Tests** so `reports/history/index.json` is populated |
| No screenshots in Run Detail | Playwright only attaches artifacts for failures/retries; check the archived `test-results` folder for that run |

## Stop the server

Press `Ctrl+C` in the terminal where `npm run executor` is running.

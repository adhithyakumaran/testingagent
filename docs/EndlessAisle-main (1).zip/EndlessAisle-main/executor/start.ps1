# Endless Aisle — Test Executor launcher (PowerShell)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ── Find Node.js ─────────────────────────────────────────────────────────────
$nodeExe = $null
$localNode = Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe'

if (Test-Path $localNode) {
  $nodeExe = $localNode
  $env:Path = "$env:LOCALAPPDATA\Programs\nodejs;$env:Path"
} elseif (Get-Command node -ErrorAction SilentlyContinue) {
  $nodeExe = 'node'
} else {
  Write-Host ''
  Write-Host '  ERROR: Node.js not found.' -ForegroundColor Red
  Write-Host '  Install from https://nodejs.org/ (LTS) and re-run.' -ForegroundColor Red
  Write-Host ''
  Read-Host 'Press Enter to exit'
  exit 1
}

Set-Location (Join-Path $PSScriptRoot '..')

Write-Host ''
Write-Host '  Freeing port 9500 if in use...' -ForegroundColor DarkGray
& $nodeExe scripts/free-port.mjs
Write-Host ''
Write-Host '  Starting Endless Aisle Test Executor...' -ForegroundColor Cyan
Write-Host "  Open in browser: http://localhost:9500" -ForegroundColor Green
Write-Host '  Ctrl+C to stop'
Write-Host ''

& $nodeExe executor/server.js

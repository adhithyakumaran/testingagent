# Endless Aisle — restart executor (free port + start)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
Write-Host ''
Write-Host '  Restarting executor (free port, then start)...' -ForegroundColor Cyan
Write-Host ''
& node scripts/restart-executor.mjs

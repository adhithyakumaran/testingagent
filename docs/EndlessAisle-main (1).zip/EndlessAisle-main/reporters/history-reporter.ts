import type {
  FullConfig,
  FullResult,
  Reporter,
  Suite,
  TestCase,
  TestResult,
} from '@playwright/test/reporter';
import * as path from 'path';
import { archiveCurrentRun, inferSuiteCategory } from './dashboard-generator';
import type { RunMeta, RunStats, TestRecord, TestStatus } from './types';

function formatRunId(date: Date, suiteName: string): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  const stamp = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}_${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
  return `${stamp}_${suiteName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
}

function mapStatus(result: TestResult): TestStatus {
  if (result.status === 'passed') return 'passed';
  if (result.status === 'failed') return 'failed';
  if (result.status === 'timedOut') return 'timedOut';
  if (result.status === 'skipped') return 'skipped';
  return 'interrupted';
}

function suiteTitle(test: TestCase): string {
  let suite: Suite | undefined = test.parent;
  while (suite?.parent && suite.parent.title) {
    suite = suite.parent;
  }
  return suite?.title ?? 'Unknown suite';
}

function buildStats(tests: TestRecord[]): RunStats {
  const passed = tests.filter((t) => t.status === 'passed').length;
  const failed = tests.filter((t) => t.status === 'failed' || t.status === 'timedOut').length;
  const skipped = tests.filter((t) => t.status === 'skipped').length;
  const interrupted = tests.filter((t) => t.status === 'interrupted').length;
  const total = tests.length;
  const passRate = total > 0 ? Math.round((passed / total) * 1000) / 10 : 0;
  return { passed, failed, skipped, interrupted, total, passRate };
}

export default class HistoryReporter implements Reporter {
  private startedAt = new Date();
  private tests: TestRecord[] = [];

  onBegin(_config: FullConfig, _suite: Suite): void {
    this.startedAt = new Date();
    this.tests = [];
  }

  onTestEnd(test: TestCase, result: TestResult): void {
    const suiteName = suiteTitle(test);
    const existing = this.tests.findIndex((t) => t.id === test.id);
    const record: TestRecord = {
      id: test.id,
      title: test.title,
      suite: suiteName,
      suiteCategory: inferSuiteCategory(suiteName),
      tags: test.tags.map((t) => t.replace(/^@/, '')),
      status: mapStatus(result),
      durationMs: result.duration,
      error: result.error?.message?.slice(0, 500),
    };
    if (existing >= 0) {
      this.tests[existing] = record;
    } else {
      this.tests.push(record);
    }
  }

  onEnd(result: FullResult): void {
    if (process.env.EXECUTOR_TEST_DISCOVERY === '1') return;
    if (this.tests.length === 0) return;

    const finishedAt = new Date();
    const suiteName = process.env.RUN_SUITE?.trim() || 'all';
    const runTag = process.env.RUN_TAG?.trim() || '';
    const runId = formatRunId(this.startedAt, suiteName);
    const stats = buildStats(this.tests);
    const failedTests = this.tests
      .filter((t) => t.status === 'failed' || t.status === 'timedOut')
      .map((t) => t.title);

    const run: RunMeta = {
      runId,
      suiteName,
      runTag,
      project: 'chromium',
      startedAt: this.startedAt.toISOString(),
      finishedAt: finishedAt.toISOString(),
      durationMs: finishedAt.getTime() - this.startedAt.getTime(),
      status: result.status,
      stats,
      tests: this.tests,
      failedTests,
      reportUrl: `/reports/history/${runId}/html-report/index.html`,
    };

    try {
      archiveCurrentRun(run);
      console.log(`\n[history] Archived run → reports/history/${runId}`);
      console.log(`[history] Dashboard updated → reports/dashboard/index.html`);
      console.log(`[history] Open dashboard: npm run dashboard  →  http://localhost:9401/dashboard/\n`);
    } catch (err) {
      console.error('[history] Failed to archive run:', err);
    }
  }
}

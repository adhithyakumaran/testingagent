import { generateDashboard } from './dashboard-generator';

generateDashboard();
console.log('Dashboard regenerated → reports/dashboard/index.html');

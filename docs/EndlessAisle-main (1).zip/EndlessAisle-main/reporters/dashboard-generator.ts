import * as fs from 'fs';
import * as path from 'path';
import type { DashboardModel, FailureHotspot, HistoryIndex, RunMeta } from './types';

const HISTORY_DIR = path.join(process.cwd(), 'reports', 'history');
const INDEX_PATH = path.join(HISTORY_DIR, 'index.json');
const DASHBOARD_DIR = path.join(process.cwd(), 'reports', 'dashboard');
const DASHBOARD_HTML = path.join(DASHBOARD_DIR, 'index.html');

export function loadHistoryIndex(): HistoryIndex {
  if (!fs.existsSync(INDEX_PATH)) {
    return { version: 1, updatedAt: new Date().toISOString(), totalRuns: 0, runs: [] };
  }
  return JSON.parse(fs.readFileSync(INDEX_PATH, 'utf8')) as HistoryIndex;
}

export function saveHistoryIndex(index: HistoryIndex): void {
  fs.mkdirSync(HISTORY_DIR, { recursive: true });
  index.updatedAt = new Date().toISOString();
  index.totalRuns = index.runs.length;
  fs.writeFileSync(INDEX_PATH, JSON.stringify(index, null, 2), 'utf8');
}

export function appendRunToIndex(run: RunMeta): void {
  const index = loadHistoryIndex();
  index.runs = index.runs.filter((r) => r.runId !== run.runId);
  index.runs.unshift(run);
  saveHistoryIndex(index);
}

function buildFailureHotspots(runs: RunMeta[]): FailureHotspot[] {
  const map = new Map<string, FailureHotspot>();
  for (const run of runs) {
    for (const test of run.tests) {
      if (test.status !== 'failed' && test.status !== 'timedOut') continue;
      const existing = map.get(test.id);
      if (existing) {
        existing.failCount += 1;
        existing.lastFailedRunId = run.runId;
        existing.lastError = test.error ?? existing.lastError;
      } else {
        map.set(test.id, {
          testId: test.id,
          title: test.title,
          suiteCategory: test.suiteCategory,
          failCount: 1,
          lastFailedRunId: run.runId,
          lastError: test.error,
        });
      }
    }
  }
  return [...map.values()].sort((a, b) => b.failCount - a.failCount).slice(0, 15);
}

function buildFlakyCandidates(runs: RunMeta[]): DashboardModel['flakyCandidates'] {
  const recent = runs.slice(0, 20);
  const byTest = new Map<string, RunMeta['tests'][0]['status'][]>();

  for (const run of recent) {
    for (const test of run.tests) {
      const statuses = byTest.get(test.id) ?? [];
      statuses.push(test.status);
      byTest.set(test.id, statuses);
    }
  }

  const flaky: DashboardModel['flakyCandidates'] = [];
  for (const [testId, statuses] of byTest) {
    const hasPass = statuses.includes('passed');
    const hasFail = statuses.some((s) => s === 'failed' || s === 'timedOut');
    if (hasPass && hasFail) {
      const title = recent.flatMap((r) => r.tests).find((t) => t.id === testId)?.title ?? testId;
      flaky.push({ testId, title, changes: statuses.length });
    }
  }
  return flaky.sort((a, b) => b.changes - a.changes).slice(0, 10);
}

export function buildDashboardModel(): DashboardModel {
  const index = loadHistoryIndex();
  const runs = index.runs;
  const totalTests = runs.reduce((n, r) => n + r.stats.total, 0);
  const totalPassed = runs.reduce((n, r) => n + r.stats.passed, 0);
  const allTimePassRate = totalTests > 0 ? Math.round((totalPassed / totalTests) * 1000) / 10 : 0;

  const suiteNames = [...new Set(runs.map((r) => r.suiteName))].sort();
  const trend = runs
    .slice(0, 30)
    .reverse()
    .map((r) => ({
      runId: r.runId,
      label: r.startedAt.slice(0, 16).replace('T', ' '),
      suiteName: r.suiteName,
      passRate: r.stats.passRate,
      passed: r.stats.passed,
      failed: r.stats.failed,
      total: r.stats.total,
      status: r.status,
    }));

  const suiteHealth = suiteNames.map((suiteName) => {
    const suiteRuns = runs.filter((r) => r.suiteName === suiteName);
    const passed = suiteRuns.reduce((n, r) => n + r.stats.passed, 0);
    const total = suiteRuns.reduce((n, r) => n + r.stats.total, 0);
    const failed = suiteRuns.reduce((n, r) => n + r.stats.failed, 0);
    return {
      suiteName,
      runs: suiteRuns.length,
      passRate: total > 0 ? Math.round((passed / total) * 1000) / 10 : 0,
      failed,
    };
  });

  return {
    generatedAt: new Date().toISOString(),
    totalRuns: runs.length,
    allTimePassRate,
    lastRun: runs[0],
    runs,
    suiteNames,
    trend,
    suiteHealth,
    failureHotspots: buildFailureHotspots(runs),
    flakyCandidates: buildFlakyCandidates(runs),
  };
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function statusBadge(status: string): string {
  const cls =
    status === 'passed'
      ? 'badge-pass'
      : status === 'failed' || status === 'timedOut'
        ? 'badge-fail'
        : 'badge-skip';
  return `<span class="badge ${cls}">${escapeHtml(status)}</span>`;
}

function renderDashboardHtml(model: DashboardModel): string {
  const trendBars = model.trend
    .map(
      (t) => `<div class="trend-item chart-bar" role="button" tabindex="0"
        data-run-id="${escapeHtml(t.runId)}" data-suite="${escapeHtml(t.suiteName)}"
        data-pass-rate="${t.passRate}" data-passed="${t.passed}" data-failed="${t.failed}"
        data-total="${t.total}" data-label="${escapeHtml(t.label)}" data-status="${escapeHtml(t.status)}"
        data-report="/reports/history/${escapeHtml(t.runId)}/html-report/index.html">
        <div class="trend-bar ${t.failed > 0 ? 'has-fail' : ''}" style="height:${Math.max(8, t.passRate)}%"></div>
        <span class="trend-label">${escapeHtml(t.label.slice(5, 16))}</span>
      </div>`
    )
    .join('');

  const suiteCards = model.suiteHealth
    .map(
      (s) => `<div class="suite-card">
        <h3>${escapeHtml(s.suiteName)}</h3>
        <p class="big">${s.passRate}%</p>
        <p class="muted">${s.runs} runs · ${s.failed} failures</p>
      </div>`
    )
    .join('');

  const hotspots = model.failureHotspots
    .map(
      (h) => `<tr>
        <td>${escapeHtml(h.title)}</td>
        <td>${escapeHtml(h.suiteCategory)}</td>
        <td><strong>${h.failCount}</strong></td>
        <td><a href="/reports/history/${escapeHtml(h.lastFailedRunId)}/html-report/index.html">Last fail run</a></td>
        <td class="error-cell">${h.lastError ? escapeHtml(h.lastError.slice(0, 120)) : '—'}</td>
      </tr>`
    )
    .join('');

  const flaky = model.flakyCandidates
    .map(
      (f) => `<tr><td>${escapeHtml(f.title)}</td><td>${f.changes} runs</td><td class="muted">Pass/fail mix in recent history</td></tr>`
    )
    .join('');

  const last = model.lastRun;
  const lastSummary = last
    ? `${statusBadge(last.status)} ${escapeHtml(last.suiteName)} — ${last.stats.passed}/${last.stats.total} passed — <a href="${escapeHtml(last.reportUrl)}">View report</a>`
    : 'No runs archived yet.';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Endless Aisle — QA Test Intelligence</title>
  <style>
    :root {
      --bg: #0f1419;
      --surface: #1a2332;
      --surface2: #243044;
      --text: #e7ecf3;
      --muted: #8b9cb3;
      --accent: #3b82f6;
      --pass: #22c55e;
      --fail: #ef4444;
      --skip: #eab308;
      --border: #2d3a4f;
    }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: "Segoe UI", system-ui, sans-serif; background: var(--bg); color: var(--text); line-height: 1.5; }
    header { padding: 1.5rem 2rem; background: linear-gradient(135deg, #1e3a5f 0%, #0f1419 100%); border-bottom: 1px solid var(--border); }
    header h1 { margin: 0 0 0.25rem; font-size: 1.5rem; font-weight: 600; }
    header p { margin: 0; color: var(--muted); font-size: 0.9rem; }
    main { padding: 1.5rem 2rem 3rem; max-width: 1400px; margin: 0 auto; }
    .kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
    .kpi { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 1rem 1.25rem; }
    .kpi .label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.06em; color: var(--muted); }
    .kpi .value { font-size: 1.75rem; font-weight: 700; margin-top: 0.25rem; }
    .kpi.pass .value { color: var(--pass); }
    .kpi.fail .value { color: var(--fail); }
    section { margin-bottom: 2rem; }
    section h2 { font-size: 1.1rem; margin: 0 0 1rem; font-weight: 600; }
    .panel { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 1.25rem; overflow: hidden; }
    .last-run { margin-bottom: 1.5rem; padding: 1rem; background: var(--surface2); border-radius: 8px; font-size: 0.95rem; }
    .trend { display: flex; align-items: flex-end; gap: 4px; height: 120px; padding-top: 1rem; overflow: visible; position: relative; }
    .trend-item { flex: 1; display: flex; flex-direction: column; align-items: center; min-width: 0; cursor: pointer; }
    .trend-item:hover .trend-bar { filter: brightness(1.08); opacity: .92; }
    .trend-bar { width: 100%; max-width: 28px; background: var(--pass); border-radius: 4px 4px 0 0; min-height: 8px; transition: filter .15s, opacity .15s; }
    .trend-bar.has-fail { background: linear-gradient(to top, var(--fail) 20%, var(--pass) 20%); }
    .trend-label { font-size: 0.6rem; color: var(--muted); margin-top: 4px; transform: rotate(-45deg); white-space: nowrap; pointer-events: none; }
    .trend-tooltip {
      position: fixed; z-index: 9999; display: none; pointer-events: none;
      min-width: 220px; max-width: 320px; padding: .65rem .8rem;
      background: var(--surface2); border: 1px solid var(--border); border-radius: 8px;
      box-shadow: 0 8px 28px rgba(0,0,0,.35); font-size: .78rem; line-height: 1.45;
    }
    .trend-tooltip strong { display: block; font-size: .82rem; margin-bottom: .2rem; }
    .trend-tooltip .tt-meta { color: var(--muted); font-size: .72rem; margin-top: .35rem; }
    .trend-tooltip .tt-hint { color: var(--accent); font-size: .68rem; margin-top: .4rem; }
    .suite-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 1rem; }
    .suite-card { background: var(--surface2); border-radius: 8px; padding: 1rem; text-align: center; }
    .suite-card h3 { margin: 0 0 0.5rem; font-size: 0.85rem; color: var(--muted); text-transform: uppercase; }
    .suite-card .big { margin: 0; font-size: 1.5rem; font-weight: 700; }
    .filters { display: flex; gap: 0.75rem; flex-wrap: wrap; margin-bottom: 1rem; }
    .filters select, .filters input { background: var(--surface2); border: 1px solid var(--border); color: var(--text); padding: 0.5rem 0.75rem; border-radius: 6px; }
    table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
    th, td { text-align: left; padding: 0.65rem 0.75rem; border-bottom: 1px solid var(--border); vertical-align: top; }
    th { color: var(--muted); font-weight: 600; font-size: 0.75rem; text-transform: uppercase; }
    tr:hover td { background: var(--surface2); }
    .badge { display: inline-block; padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; }
    .badge-pass { background: rgba(34,197,94,0.2); color: var(--pass); }
    .badge-fail { background: rgba(239,68,68,0.2); color: var(--fail); }
    .badge-skip { background: rgba(234,179,8,0.2); color: var(--skip); }
    .btn { color: var(--accent); text-decoration: none; font-weight: 500; }
    .btn:hover { text-decoration: underline; }
    .muted { color: var(--muted); font-size: 0.8rem; }
    .fail-list { margin: 0; padding-left: 1rem; font-size: 0.75rem; color: var(--fail); }
    .error-cell { font-size: 0.75rem; color: var(--muted); max-width: 280px; word-break: break-word; }
    footer { text-align: center; padding: 2rem; color: var(--muted); font-size: 0.8rem; }
  </style>
</head>
<body>
  <header>
    <h1>Endless Aisle — QA Test Intelligence</h1>
    <p>Product Catalogue · Historical runs (never deleted) · Generated ${escapeHtml(model.generatedAt.replace('T', ' ').slice(0, 19))}</p>
  </header>
  <main>
    <div class="kpis">
      <div class="kpi"><div class="label">Total runs archived</div><div class="value">${model.totalRuns}</div></div>
      <div class="kpi pass"><div class="label">All-time pass rate</div><div class="value">${model.allTimePassRate}%</div></div>
      <div class="kpi fail"><div class="label">Failure hotspots</div><div class="value">${model.failureHotspots.length}</div></div>
      <div class="kpi"><div class="label">Flaky candidates</div><div class="value">${model.flakyCandidates.length}</div></div>
    </div>

    <div class="last-run panel"><strong>Latest run:</strong> ${lastSummary}</div>

    <section>
      <h2>Pass rate trend (last ${model.trend.length} runs)</h2>
      <div class="panel trend">${trendBars || '<p class="muted">No trend data yet.</p>'}</div>
    </section>

    <section>
      <h2>Suite health</h2>
      <div class="suite-grid">${suiteCards || '<p class="muted">No suite data.</p>'}</div>
    </section>

    <section>
      <h2>Failure hotspots (all time)</h2>
      <div class="panel">
        <table>
          <thead><tr><th>Test</th><th>Suite</th><th>Failures</th><th>Last fail</th><th>Error snippet</th></tr></thead>
          <tbody>${hotspots || '<tr><td colspan="5" class="muted">No failures recorded.</td></tr>'}</tbody>
        </table>
      </div>
    </section>

    <section>
      <h2>Flaky candidates (recent pass/fail mix)</h2>
      <div class="panel">
        <table>
          <thead><tr><th>Test</th><th>Recent runs</th><th>Note</th></tr></thead>
          <tbody>${flaky || '<tr><td colspan="3" class="muted">None detected.</td></tr>'}</tbody>
        </table>
      </div>
    </section>

  </main>
  <footer>Reports stored under <code>reports/history/</code> — never auto-deleted. Run history is available in the <strong>History</strong> tab of the Executor UI.</footer>
  <div id="trendTooltip" class="trend-tooltip"></div>
  <script>
    (function () {
      const wrap = document.querySelector('.panel.trend');
      const tip = document.getElementById('trendTooltip');
      if (!wrap || !tip) return;

      function hideTip() { tip.style.display = 'none'; }

      function showTip(e, bar) {
        tip.innerHTML =
          '<strong>' + (bar.dataset.label || 'Run') + '</strong>' +
          '<div>' + (bar.dataset.suite || '') + '</div>' +
          '<div>' + bar.dataset.passRate + '% pass · ' + bar.dataset.passed + '/' + bar.dataset.total +
          ' passed · ' + bar.dataset.failed + ' failed</div>' +
          '<div class="tt-meta">Status: ' + (bar.dataset.status || '—') + ' · ' + (bar.dataset.runId || '') + '</div>' +
          '<div class="tt-hint">Click to open report</div>';
        tip.style.display = 'block';
        const pad = 12;
        const rect = tip.getBoundingClientRect();
        let left = e.clientX + pad;
        let top = e.clientY + pad;
        if (left + rect.width > window.innerWidth - 8) left = e.clientX - rect.width - pad;
        if (top + rect.height > window.innerHeight - 8) top = e.clientY - rect.height - pad;
        tip.style.left = Math.max(8, left) + 'px';
        tip.style.top = Math.max(8, top) + 'px';
      }

      wrap.addEventListener('mousemove', (e) => {
        const bar = e.target.closest('.chart-bar');
        if (!bar) { hideTip(); return; }
        showTip(e, bar);
      });
      wrap.addEventListener('mouseleave', hideTip);
      wrap.addEventListener('click', (e) => {
        const bar = e.target.closest('.chart-bar');
        if (!bar?.dataset.report) return;
        hideTip();
        window.open(bar.dataset.report, '_blank', 'noopener');
      });
      wrap.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        const bar = e.target.closest('.chart-bar');
        if (!bar?.dataset.report) return;
        e.preventDefault();
        hideTip();
        window.open(bar.dataset.report, '_blank', 'noopener');
      });
    })();
  </script>
</body>
</html>`;
}

export function generateDashboard(): void {
  const model = buildDashboardModel();
  fs.mkdirSync(DASHBOARD_DIR, { recursive: true });
  fs.writeFileSync(DASHBOARD_HTML, renderDashboardHtml(model), 'utf8');
  fs.writeFileSync(path.join(DASHBOARD_DIR, 'data.json'), JSON.stringify(model, null, 2), 'utf8');
}

export function copyDirSafe(src: string, dest: string): void {
  if (!fs.existsSync(src)) return;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.cpSync(src, dest, { recursive: true });
}

export function archiveCurrentRun(run: RunMeta): void {
  const runDir = path.join(HISTORY_DIR, run.runId);
  fs.mkdirSync(runDir, { recursive: true });

  copyDirSafe(path.join(process.cwd(), 'reports', 'html-report'), path.join(runDir, 'html-report'));
  copyDirSafe(path.join(process.cwd(), 'reports', 'test-results'), path.join(runDir, 'test-results'));

  fs.writeFileSync(path.join(runDir, 'run-meta.json'), JSON.stringify(run, null, 2), 'utf8');
  appendRunToIndex(run);
  generateDashboard();
}

export function inferSuiteCategory(suiteTitle: string): string {
  if (/smoke/i.test(suiteTitle)) return 'Smoke';
  if (/positive/i.test(suiteTitle)) return 'Positive';
  if (/negative/i.test(suiteTitle)) return 'Negative';
  return 'Other';
}

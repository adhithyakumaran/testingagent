export type TestStatus = 'passed' | 'failed' | 'timedOut' | 'skipped' | 'interrupted';

export interface TestRecord {
  id: string;
  title: string;
  suite: string;
  suiteCategory: string;
  tags: string[];
  status: TestStatus;
  durationMs: number;
  error?: string;
}

export interface RunStats {
  passed: number;
  failed: number;
  skipped: number;
  interrupted: number;
  total: number;
  passRate: number;
}

export interface RunMeta {
  runId: string;
  suiteName: string;
  runTag: string;
  project: string;
  startedAt: string;
  finishedAt: string;
  durationMs: number;
  status: 'passed' | 'failed' | 'timedOut' | 'skipped';
  stats: RunStats;
  tests: TestRecord[];
  failedTests: string[];
  reportUrl: string;
}

export interface HistoryIndex {
  version: 1;
  updatedAt: string;
  totalRuns: number;
  runs: RunMeta[];
}

export interface FailureHotspot {
  testId: string;
  title: string;
  suiteCategory: string;
  failCount: number;
  lastFailedRunId: string;
  lastError?: string;
}

export interface DashboardModel {
  generatedAt: string;
  totalRuns: number;
  allTimePassRate: number;
  lastRun?: RunMeta;
  runs: RunMeta[];
  suiteNames: string[];
  trend: { runId: string; label: string; suiteName: string; passRate: number; passed: number; failed: number; total: number; status: string }[];
  suiteHealth: { suiteName: string; runs: number; passRate: number; failed: number }[];
  failureHotspots: FailureHotspot[];
  flakyCandidates: { testId: string; title: string; changes: number }[];
}
